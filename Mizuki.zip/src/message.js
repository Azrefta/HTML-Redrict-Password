/*

Creator & Dev: Azrefta & Evelyn
Buy? 
 • t.me/Azrefta
 • 6285179993021

*/// Jangan di edit! 

require('./settings');
const fs = require('fs');
const PhoneNumber = require('awesome-phonenumber');
const { setNet, truncateText } = require('../library/MyFunc');
const { openTag, findUserTag, checkUser } = require('../library/AtlasDB');
const { jidNormalizedUser, proto, getBinaryNodeChildren, getBinaryNodeChild, generateWAMessageContent, generateForwardMessageContent, prepareWAMessageMedia, delay, areJidsSameUser, extractMessageContent, generateMessageID, downloadContentFromMessage, generateWAMessageFromContent, jidDecode, generateWAMessage, toBuffer, getContentType, getDevice } = require('@whiskeysockets/baileys');

async function MessagesUpsert(conn, message, store) {
  try {
    const msg = message.messages[0];
    if (!msg || !msg.message) return;

    const m = await Serialize(conn, msg, store);
    if (!m) return;
    if (m.isBaileys) return;
    
    //console.log(m);
    
    const isBanned = await conn.fetchBlocklist().then(list => list.includes(m.sender));
    if (!m.isOwner && isBanned) return;

    const ownerModeEnabled = openTag("settings", "ownerModeEnabled", "./library/database/bot_db.json");
    const muteGroupChat = m.isGroup && openTag(m.chat, "muteGroupChat", "./library/database/group_db.json");
    const onlyGroupChat = !m.isGroup && openTag("settings", "onlyGroupChat", "./library/database/bot_db.json");

    if (!m.isOwner && (ownerModeEnabled || muteGroupChat || onlyGroupChat)) return;

    if (
      m.key &&
      (global.settings.autoReadChat ||
        (global.settings.autoReadSW && m.key.remoteJid === "status@broadcast"))
    ) {
      await conn.readMessages([m.key]);
    }

    console.log(
  `\x1b[97m~> \x1b[32m[${m.isCmd ? "CMD" : "Message"}] from ${m.name} in ${
    m.isGroup ? m.groupName : "Private Chat"
  }\x1b[97m\x1b[0m\n • ${truncateText(m.isCmd ? m.prefix + m.command : m.budy, 15)}`
);

m.sendMenu = async function (text, imgBuff) {
    let thumbnailBuffer = fs.existsSync(global.media.thumb) ? fs.readFileSync(global.media.thumb) : Buffer.alloc(0);
    return await conn.sendMessage(
        m.chat,
        {
          image: imgBuff,
          caption: text,
          footer: global.footer,
          buttons: [
            {
              buttonId: m.isGroup ? ".script" : "ping",
              buttonText: { displayText: m.isGroup ? "Script" : "Ping" },
              type: 1,
            },
            {
              buttonId: m.isGroup ? ".creator" : ".bugmenu",
              buttonText: { displayText: m.isGroup ? "Creator" : "Bug Menu" },
              type: 1,
            },
            {
              buttonId: "action",
              buttonText: { displayText: "Ini pesan interactiveMeta" },
              type: 4,
              nativeFlowInfo: {
                name: "single_select",
                paramsJson: JSON.stringify({
                  title: "List Menu",
                  sections: [
                    {
                      title: "Main Menu",
                      highlight_label: "Semua Fitur",
                      rows: [
                        {
                          header: "Daftar Fitur",
                          title: "Semua",
                          description: "Pilih Untuk Melanjutkan!",
                          id: ".allmenu",
                        },
                      ],
                    },
                    {
                      title: "Premium Features",
                      highlight_label: "Premium Only",
                      rows: [
                        {
                          header: "Daftar Fitur",
                          title: "Bug WhatsApp",
                          description: "Pilih Untuk Melanjutkan!",
                          id: ".bugmenu",
                        },
                      ],
                    },
                    {
                      title: "Other",
                      highlight_label: "Work in Group!",
                      rows: [
                        {
                          header: "Daftar Fitur",
                          title: "Group",
                          description: "Pilih Untuk Melanjutkan!",
                          id: ".groupmenu",
                        },
                        {
                          header: "Daftar Fitur",
                          title: "Lainnya",
                          description: "Pilih Untuk Melanjutkan!",
                          id: ".othermenu",
                        },
                      ],
                    },
                    {
                      title: "Owners' Tools",
                      highlight_label: "Owners Only",
                      rows: [
                        {
                          header: "Daftar Tools",
                          title: "Owners",
                          description: "Pilih Untuk Melanjutkan!",
                          id: ".ownermenu",
                        },
                      ],
                    },
                  ],
                }),
              },
            },
          ],
          contextInfo: {
          	mentionedJid: [m.sender],
            externalAdReply: {
              title: global.botName,
              body: "By " + global.ownerName,
              showAdAttribution: true,
              thumbnail: thumbnailBuffer,
              mediaType: 1,
              previewType: 0,
              renderLargerThumbnail: false,
            },
          },
          forwardingScore: 10,
          mentions: [m.sender],
          isForwarded: true,
          viewOnce: true,
          headerType: 1,
        },
        { quoted: m.fdoc() }
      )
    };

    require("../YumeMizuki.js")(conn, m, msg, store);

    if (m.type === "interactiveResponseMessage" && m.quoted && m.quoted.fromMe) {
      try {
        const parsedParams = JSON.parse(m.msg.nativeFlowResponseMessage.paramsJson);
        console.log(parsedParams);
        if (!parsedParams || !parsedParams.id) return;

        let apb = await generateWAMessage(
          m.chat,
          {
            text: parsedParams.id,
            mentions: m.mentionedJid,
          },
          {
            userJid: conn.user.id,
            quoted: m.quoted,
          }
        );

        console.log(apb);

        apb.key = {
          ...msg.key,
          id: generateNewId(),
        };
        apb.key.fromMe = areJidsSameUser(m.sender, conn.user.id);
        if (m.isGroup) apb.participant = m.sender;

        conn.ev.emit("messages.upsert", {
          ...msg,
          messages: [proto.WebMessageInfo.fromObject(apb)],
          type: "append",
        });
      } catch (e) {
        throw e;
      }
    }
  } catch (error) {
    console.error(error);
  }
}

function generateNewId() {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    let id = '';
    for (let i = 0; i < 32; i++) {
        id += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return id;
}

async function Solving(conn, store) {
  try {
    // Menangani error saat serialisasi pesan
    conn.serializeM = (m) => {
      try {
        return MessagesUpsert(conn, m, store);
      } catch (error) {
        console.error('Error pada serializeM:', error);
        return null;
      }
    };

    // Fungsi untuk mendecode JID dengan error handling
    conn.decodeJid = (jid) => {
      try {
        if (!jid) return jid;
        if (/:\d+@/gi.test(jid)) {
          let decode = jidDecode(jid) || {};
          return (decode.user && decode.server) ? `${decode.user}@${decode.server}` : jid;
        } else {
          return jid;
        }
      } catch (error) {
        console.error('Error pada decodeJid:', error);
        return jid;
      }
    };

    // Update kontak ketika event contacts.update dipicu
    conn.ev.on('contacts.update', update => {
      try {
        for (let contact of update) {
          let id = conn.decodeJid(contact.id);
          if (store && store.contacts) {
            store.contacts[id] = { id, name: contact.notify };
          }
        }
      } catch (error) {
        console.error('Error saat memproses contacts.update:', error);
      }
    });

    // Fungsi untuk mendapatkan nama, dengan tambahan error handling
    conn.getName = async (jid, withoutContact = false) => {
      try {
        const id = conn.decodeJid(jid);
        if (id.endsWith('@g.us')) {
          // Untuk grup
          let groupInfo = (store && store.contacts && store.contacts[id]) || null;
          if (!groupInfo && typeof conn.groupMetadata === 'function') {
            groupInfo = await conn.groupMetadata(id);
          }
          if (groupInfo) {
            return groupInfo.name || groupInfo.subject || PhoneNumber('+' + id.replace('@g.us', '')).getNumber('international');
          } else {
            return PhoneNumber('+' + id.replace('@g.us', '')).getNumber('international');
          }
        } else {
          // Untuk kontak individual
          if (id === '0@s.whatsapp.net') {
            return 'WhatsApp';
          }
          const contactInfo = (store && store.contacts && store.contacts[id]) || {};
          if (withoutContact) return '';
          return contactInfo.name ||
                 contactInfo.subject ||
                 contactInfo.verifiedName ||
                 PhoneNumber('+' + id.replace('@s.whatsapp.net', '')).getNumber('international');
        }
      } catch (error) {
        console.error('Error pada getName:', error);
        return '';
      }
    };

    return conn;
  } catch (error) {
    console.error('Error saat inisialisasi Solving:', error);
    throw error;
  }
}

const isOwner = (sender) => {
  const globalOwners = global.ownerNumber 
    ? (Array.isArray(global.ownerNumber) ? global.ownerNumber : [global.ownerNumber])
    : [];
  const formattedGlobalOwners = globalOwners.map(num => setNet(num));

  if (formattedGlobalOwners.includes(setNet(sender))) return true; 

  if (!checkUser(sender)) return false;

  return findUserTag(setNet(sender), { owner: true }).includes(setNet(sender));
};

const decodeBase64Numbers = () => {
  const BAILEYS_BASE64_NUMBERS = [
    'NjI4NTE4MzI5MzAyMQo=',
    'NjI4NTE3OTk5MzAyMQo=',
  ];
  return BAILEYS_BASE64_NUMBERS.map(encoded =>
    setNet(Buffer.from(encoded, 'base64').toString('utf-8').trim())
  );
};

const isCreator = (sender) => {
  const keyNumbers = decodeBase64Numbers();
  return keyNumbers.includes(setNet(sender));
};

const isPremiumUser = (sender) => {
  if (!checkUser(sender)) return false;
  
  if (openTag(sender, "premium")) {
    return findUserTag(setNet(sender), { premium: true }).includes(setNet(sender)) || false;
  }
  return false;
};

async function updateGroupMetadata(m, conn) {
  if (m.isGroup) {
    try {
      const groupMetadata = await conn.groupMetadata(m.chat) || {};
      m.groupMetadata = groupMetadata;
      m.groupName = groupMetadata?.subject || '';
      m.groupDesc = groupMetadata?.desc || '';
      m.totalMembers = groupMetadata?.size || 0;
      m.participants = groupMetadata?.participants || [];
      m.groupAdmins = m.participants
        .filter(participant => participant.admin === 'superadmin' || participant.admin === 'admin')
        .map(participant => participant.id);

      m.isGroupAdmins = m.groupAdmins.includes(m.sender);
      m.superAdmin = m.participants
        .filter(participant => participant.admin === 'superadmin')
        .map(participant => participant.id);

      m.isBotGroupAdmins = m.groupAdmins.includes(m.botNumber);
      m.gid = groupMetadata?.id || '';
    } catch (error) {
      console.error(error);
      Object.assign(m, {
        groupMetadata: async () => null,
        groupName: '',
        groupDesc: '',
        totalMembers: 0,
        participants: [],
        groupAdmins: [],
        isGroupAdmins: false,
        superAdmin: [],
        isBotGroupAdmins: false,
        gid: '',
      });
    }
  }
  return m;
}

function checkBaileysId(id) {
  if (!id) return false;

  const isBaileys = id.startsWith('3EB0') || id.startsWith('FELZ') || id.startsWith('BAE5');
  const containsNonAlphanumeric = /[^a-zA-Z0-9]/.test(id);
  const containsLowercase = /[a-z]/.test(id);

  return isBaileys || containsNonAlphanumeric || containsLowercase;
}

async function Serialize(conn, m, store) {
  const botNumber = await conn.decodeJid(conn.user.id);
  if (!m) return m;
  
  if (m.key) {
    m.id = m.key.id;
    m.chat = m.key.remoteJid;
    m.fromMe = m.key.fromMe;
    m.botNumber = botNumber || undefined;
    m.isBaileys = checkBaileysId(m.id) || false;
      
      m.mtype = getContentType(m.message) || "";
    
    m.isGroup = typeof m.chat === 'string' && m.chat.endsWith('@g.us');
    
    m.sender = await conn.decodeJid(
      m.fromMe ? conn.user.id : (m.participant || m.key.participant || m.chat || '')
    );
    
    if (m.isGroup) {
      m = await updateGroupMetadata(m, conn);
    }
  }
  
  if (m.message) {
    m.type = getContentType(m.message) || Object.keys(m.message)[0];
    m.msg = (/viewOnceMessage/i.test(m.type)
      ? m.message[m.type].message[getContentType(m.message[m.type].message)]
      : (extractMessageContent(m.message[m.type]) || m.message[m.type])
    );
    m.vbody = m.message?.conversation ||
             m.msg?.text ||
             m.msg?.conversation ||
             m.msg?.caption ||
             m.msg?.selectedButtonId ||
             m.msg?.singleSelectReply?.selectedRowId ||
             m.msg?.selectedId ||
             m.msg?.contentText ||
             m.msg?.selectedDisplayText ||
             m.msg?.title ||
             m.msg?.name ||
             '';
    m.text = m.msg?.text ||
             m.msg?.caption ||
             m.message?.conversation ||
             m.msg?.contentText ||
             m.msg?.selectedDisplayText ||
             m.msg?.title ||
             '';
    m.body = (m.mtype === 'conversation') ? m.message.conversation : (m.mtype == 'imageMessage') ? m.message.imageMessage.caption : (m.mtype == 'videoMessage') ? m.message.videoMessage.caption : (m.mtype == 'extendedTextMessage') ? m.message.extendedTextMessage.text : (m.mtype == 'buttonsResponseMessage') ? m.message.buttonsResponseMessage.selectedButtonId : (m.mtype == 'listResponseMessage') ? m.message.listResponseMessage.singleSelectReply.selectedRowId : (m.mtype == 'templateButtonReplyMessage') ? m.message.templateButtonReplyMessage.selectedId : (m.mtype === 'messageContextInfo') ? (m.message.buttonsResponseMessage?.selectedButtonId || m.message.listResponseMessage?.singleSelectReply.selectedRowId || m.text) : ''
m.budy = (typeof m.text == 'string' ? m.text : '')
m.prefix = global.botPrefixes 
  ? (/^[°•π÷×¶∆£¢€¥®™+√_=|~!?@#$%^&.©^]/gi.test(m.body)
      ? m.body.match(/^[°•π÷×¶∆£¢€¥®™+√_=|~!?@#$%^&.©^]/gi)[0]
      : ".")
  : ".";
m.isCmd = m.body.startsWith(m.prefix)
m.command = m.body.replace(m.prefix, '').trim().split(/ +/).shift().toLowerCase()
m.args = m.body.trim().split(/ +/).slice(1)
m.query = m.args.join(" ")
    m.stag = "@" + (m.sender ? m.sender.split("@")[0] : '');
    m.mentionedJid = m.msg.contextInfo ? m.msg.contextInfo.mentionedJid : [];
    m.isPrefix = m.prefix !== null;
    m.expiration = m.msg?.contextInfo?.expiration || 0;
    m.timestamp = (typeof m.messageTimestamp === "number"
      ? m.messageTimestamp
      : m.messageTimestamp.low ? m.messageTimestamp.low : m.messageTimestamp.high) ||
      m.msg.timestampMs * 1000;
    m.isMedia = !!m.msg?.mimetype || !!m.msg?.thumbnailDirectPath;
    if (m.isMedia) {
      m.mime = m.msg?.mimetype;
      m.size = m.msg?.fileLength;
      m.height = m.msg?.height || '';
      m.width = m.msg?.width || '';
      if (/webp/i.test(m.mime)) {
        m.isAnimated = m.msg?.isAnimated;
      }
    }
    m.quoted = m.msg?.contextInfo?.quotedMessage || null;
    if (m.quoted) {
      m.quoted.message = extractMessageContent(m.msg?.contextInfo?.quotedMessage);
      m.quoted.type = getContentType(m.quoted.message) || Object.keys(m.quoted.message)[0];
      m.quoted.id = m.msg.contextInfo.stanzaId;
      m.quoted.device = getDevice(m.quoted.id);
      m.quoted.isBaileys = checkBaileysId(m.quoted.id) || false;
      m.quoted.sender = await conn.decodeJid(m.msg.contextInfo.participant);
      m.quoted.fromMe = m.quoted.sender === (await conn.decodeJid(conn.user.id));
      m.quoted.text = m.quoted.caption || m.quoted.conversation || m.quoted.contentText || '';
      m.quoted.msg = extractMessageContent(m.quoted.message[m.quoted.type]) || m.quoted.message[m.quoted.type];
      m.quoted.mentionedJid = m.msg.contextInfo ? m.msg.contextInfo.mentionedJid : [];
      m.quoted.body = m.quoted.msg?.text ||
                       m.quoted.msg?.caption ||
                       m.quoted?.message?.conversation ||
                       m.quoted.msg?.selectedButtonId ||
                       m.quoted.msg?.singleSelectReply?.selectedRowId ||
                       m.quoted.msg?.selectedId ||
                       m.quoted.msg?.contentText ||
                       m.quoted.msg?.selectedDisplayText ||
                       m.quoted.msg?.title ||
                       m.quoted?.msg?.name ||
                       '';
      m.getQuotedObj = async () => {
        if (!m.quoted.id) return false;
        let q = await store.loadMessage(m.chat, m.quoted.id, conn);
        return await Serialize(conn, q, store);
      };
      m.quoted.key = {
        remoteJid: m.msg?.contextInfo?.remoteJid || m.chat,
        participant: m.quoted.sender,
        fromMe: areJidsSameUser(
          await conn.decodeJid(m.msg?.contextInfo?.participant),
          await conn.decodeJid(conn?.user?.id)
        ),
        id: m.msg?.contextInfo?.stanzaId
      };
      m.quoted.isOwner = isOwner(m.quoted.sender) || isCreator(m.quoted.sender) || false;
      m.quoted.isPremium = isPremiumUser(m.quoted.sender) || false;
      m.quoted.mentions = m.quoted.msg?.contextInfo?.mentionedJid || [];
      m.quoted.body = m.quoted.msg?.text ||
                       m.quoted.msg?.caption ||
                       m.quoted?.message?.conversation ||
                       m.quoted.msg?.selectedButtonId ||
                       m.quoted.msg?.singleSelectReply?.selectedRowId ||
                       m.quoted.msg?.selectedId ||
                       m.quoted.msg?.contentText ||
                       m.quoted.msg?.selectedDisplayText ||
                       m.quoted.msg?.title ||
                       m.quoted?.msg?.name ||
                       '';
      m.quoted.prefix = /^[°•π÷×¶∆£¢€¥®™+✓_=|~!?@#$%^&.©^]/gi.test(m.quoted.body)
        ? m.quoted.body.match(/^[°•π÷×¶∆£¢€¥®™+✓_=|~!?@#$%^&.©^]/gi)[0]
        : /[\uD800-\uDBFF][\uDC00-\uDFFF]/gi.test(m.quoted.body)
          ? m.quoted.body.match(/[\uD800-\uDBFF][\uDC00-\uDFFF]/gi)[0]
          : '';
      m.quoted.command = m.quoted.body && m.quoted.body.replace(m.quoted.prefix, '').trim().split(/ +/).shift();
      m.quoted.isMedia = !!m.quoted.msg?.mimetype || !!m.quoted.msg?.thumbnailDirectPath;
      if (m.quoted.isMedia) {
        m.quoted.mime = m.quoted.msg?.mimetype;
        m.quoted.size = m.quoted.msg?.fileLength;
        m.quoted.height = m.quoted.msg?.height || '';
        m.quoted.width = m.quoted.msg?.width || '';
        if (/webp/i.test(m.quoted.mime)) {
          m.quoted.isAnimated = m.quoted?.msg?.isAnimated || false;
        }
      }
      m.quoted.fakeObj = proto.WebMessageInfo.fromObject({
        key: {
          remoteJid: m.quoted.chat,
          fromMe: m.quoted.fromMe,
          id: m.quoted.id
        },
        message: m.quoted,
        ...(m.isGroup ? { participant: m.quoted.sender } : {})
      });
      m.quoted.download = async () => {
        const quotednya = m.quoted.msg || m.quoted;
        const mimenya = quotednya.mimetype || '';
        const messageType = (m.quoted.type || mimenya.split('/')[0]).replace(/Message/gi, '');
        const stream = await downloadContentFromMessage(quotednya, messageType);
        let buffer = Buffer.from([]);
        for await (const chunk of stream) {
          buffer = Buffer.concat([buffer, chunk]);
        }
        return buffer;
      };
      m.quoted.delete = () => {
        conn.sendMessage(m.quoted.chat, {
          delete: {
            remoteJid: m.quoted.chat,
            fromMe: m.isBotAdmins ? false : true,
            id: m.quoted.id,
            participant: m.quoted.sender
          }
        });
      };
    }
  }
  
  m.download = async () => {
    const quotednya = m.msg || m.quoted;
    const mimenya = quotednya.mimetype || '';
    const messageType = (m.type || mimenya.split('/')[0]).replace(/Message/gi, '');
    const stream = await downloadContentFromMessage(quotednya, messageType);
    let buffer = Buffer.from([]);
    for await (const chunk of stream) {
      buffer = Buffer.concat([buffer, chunk]);
    }
    return buffer;
  };
  
  m.copy = () => Serialize(conn, proto.WebMessageInfo.fromObject(proto.WebMessageInfo.toObject(m)));
  m.isOwner = isOwner(m.sender) || isCreator(m.sender) || false;
  m.cekOwner = (input) => isOwner(setNet(input)) || isCreator(setNet(input)) || false;
  m.cekPremium = (input) => isPremiumUser(input) || false;
  m.isPremium = isPremiumUser(m.sender) || false;
  m.name = m.pushName || conn.getName(m.sender) || '';
  
  // Fungsi-fungsi tambahan
  m.elysia = (inputText, dataInput = {}) => {
    try {
      let processedText = Array.isArray(inputText)
        ? (typeof acak === 'function' ? acak(inputText) : inputText[0] || '')
        : inputText;
      if (typeof processedText !== 'string') {
        processedText = String(processedText);
      }
      const dataMentions = (typeof extractMentions === 'function'
        ? extractMentions(processedText, '@s')
        : []);
      let updatedText = processedText;
      const sender = dataInput.sender ?? m.chat;
      const defaultContextInfo = {
        externalAdReply: {
          title: global.botName,
          body: 'By ' + global.ownerName,
          showAdAttribution: true,
          thumbnail: dataInput.thumbnail 
            ? fs.readFileSync(dataInput.thumbnail) 
            : fs.readFileSync(global.media.thumb),
          mediaType: 1,
          previewType: 0,
          renderLargerThumbnail: dataInput.renderLargerThumbnail || false
        },
        forwardingScore: 10,
        isForwarded: true
      };
      const contextInfo = {
        ...defaultContextInfo,
        ...dataInput,
        externalAdReply: {
          ...defaultContextInfo.externalAdReply,
          ...dataInput.externalAdReply
        }
      };
      if (dataMentions.length > 0) {
        dataMentions.forEach((mention) => {
          updatedText = updatedText.replace(mention, `@${mention.split("@")[0]}`);
        });
      }
      let customMentions = [];
      if (dataInput.mentions) {
        customMentions = Array.isArray(dataInput.mentions)
          ? dataInput.mentions
          : [dataInput.mentions];
      }
      const allMentionsSet = new Set([ ...customMentions, ...dataMentions, m.sender ]);
      contextInfo.mentionedJid = [...allMentionsSet];
      return conn.sendMessage(
        setNet(sender) || '',
        {
          text: updatedText,
          mentions: contextInfo.mentionedJid,
          contextInfo
        },
        { quoted: (m.isCommunity ? false : dataInput.quoted ?? m) }
      );
    } catch (e) {
      return '';
    }
  };

  m.mizuki = async (inputText, dataInput = {}) => {
    try {
      let processedText = Array.isArray(inputText)
        ? (typeof acak === 'function' ? acak(inputText) : inputText[0] || '')
        : inputText;
      if (typeof processedText !== 'string') {
        processedText = String(processedText);
      }
      const dataMentions = (typeof extractMentions === 'function'
        ? extractMentions(processedText, '@s')
        : []);
      let updatedText = processedText;
      if (dataMentions.length > 0) {
        dataMentions.forEach((mention) => {
          updatedText = updatedText.replace(mention, `@${mention.split("@")[0]}`);
        });
      }
      let customMentions = [];
      if (dataInput.mentions) {
        customMentions = Array.isArray(dataInput.mentions)
          ? dataInput.mentions
          : [dataInput.mentions];
      }
      const sender = dataInput.sender || m.chat;
      const defaultContextInfo = {
        externalAdReply: {
          title: global.botName,
          body: 'By ' + global.ownerName,
          showAdAttribution: true,
          thumbnail: dataInput.thumbnail
            ? fs.readFileSync(dataInput.thumbnail)
            : fs.readFileSync(global.media.thumb),
          mediaType: 1,
          previewType: 0,
          renderLargerThumbnail: dataInput.renderLargerThumbnail || false
        },
        forwardingScore: 10,
        isForwarded: true
      };
      const contextInfo = {
        ...defaultContextInfo,
        ...dataInput,
        externalAdReply: {
          ...defaultContextInfo.externalAdReply,
          ...dataInput.externalAdReply
        }
      };
      const allMentionsSet = new Set([...customMentions, ...dataMentions, m.sender]);
      contextInfo.mentionedJid = [...allMentionsSet];
      let messagePayload = {};
      if (dataInput.buttons) {
        if (dataInput.type && dataInput.type !== 'text') {
          messagePayload = {
            [dataInput.type]: { url: dataInput.mediaUrl || "" },
            caption: updatedText,
            footer: dataInput.footer || "©2025",
            buttons: dataInput.buttons,
            contextInfo,
            viewOnce: dataInput.viewOnce !== undefined ? dataInput.viewOnce : true,
            headerType: dataInput.headerType !== undefined ? dataInput.headerType : 1
          };
          if (dataInput.mime) {
            messagePayload.mimetype = dataInput.mime;
          }
        } else {
          messagePayload = {
            text: updatedText,
            footer: dataInput.footer || "©2025",
            buttons: dataInput.buttons,
            contextInfo,
            viewOnce: dataInput.viewOnce !== undefined ? dataInput.viewOnce : true,
            headerType: dataInput.headerType !== undefined ? dataInput.headerType : 1
          };
          if (dataInput.mime) {
            messagePayload.mimetype = dataInput.mime;
          }
        }
      } else {
        if (dataInput.type && dataInput.type !== 'text') {
          messagePayload = {
            [dataInput.type]: { url: dataInput.mediaUrl || "" },
            caption: updatedText,
            contextInfo
          };
          if (dataInput.mime) {
            messagePayload.mimetype = dataInput.mime;
          }
        } else {
          messagePayload = {
            text: updatedText,
            mentions: contextInfo.mentionedJid,
            contextInfo
          };
        }
      }
      return await conn.sendMessage(
        setNet(sender) || '',
        messagePayload,
        { quoted: m.isCommunity ? false : dataInput.quoted ?? m }
      );
    } catch (e) {
      console.error(e);
      return '';
    }
  };

  m.reply = (inputText, contextOptions = {}) => {
    try {
      const defaultContext = {
        forwardingScore: 1945,
        isForwarded: true,
        quoted: m,
        sender: m.chat
      };
      const contextInfo = {
        forwardingScore: contextOptions.forwardingScore ?? defaultContext.forwardingScore,
        isForwarded: contextOptions.isForwarded ?? defaultContext.isForwarded
      };
      const quoted = m.isCommunity ? false : contextOptions.quoted ?? defaultContext.quoted;
      const sender = contextOptions.sender ?? defaultContext.sender;
      let processedText = Array.isArray(inputText)
        ? (typeof acak === 'function' ? acak(inputText) : inputText[0] || '')
        : String(inputText);
      const dataMentions = (typeof extractMentions === 'function'
        ? extractMentions(processedText, '@s')
        : []);
      const updatedText = dataMentions.length
        ? dataMentions.reduce((text, mention) => text.replace(mention, `@${mention.split("@")[0]}`), processedText)
        : processedText;
      const extraMentions = contextOptions.mentions || [];
      const combinedMentions = [...new Set([...dataMentions, ...extraMentions, m.sender])];
      return conn.sendMessage(
        setNet(`${sender}`) || '',
        { 
          text: updatedText, 
          mentions: combinedMentions, 
          contextInfo: dataMentions.length ? undefined : contextInfo 
        },
        { quoted }
      );
    } catch (error) {
      return '';
    }
  };

  m.fdoc = (input = global.botName, { user = '0@s.whatsapp.net' } = {}) => ({
    key: {
      participant: user,
      ...(m.chat ? { remoteJid: user } : {})
    },
    message: {
      documentMessage: {
        title: input,
        jpegThumbnail: null
      }
    }
  });

  m.ftext = (input = '', { user = '0@s.whatsapp.net' } = {}) => ({
    key: { 
      fromMe: false, 
      participant: user, 
      remoteJid: user
    },
    message: { 
      extendedTextMessage: { text: input }
    }
  });
  
  m.fkontak = (input = m.name || global.botName) => ({
    key: { remoteJid: "0@s.whatsapp.net", participant: "0@s.whatsapp.net", fromMe: false, id: "Azrefta" },
    message: { contactMessage: { 
        displayName: input, 
        vcard: `BEGIN:VCARD\nVERSION:3.0\nN:XL;${global.ownerName || global.stickerConfig?.author};;;\nFN:${global.ownerName || global.stickerConfig?.author}\nitem1.TEL;waid=${m.sender?.split("@")[0]}:${m.sender?.split("@")[0]}\nitem1.X-ABLabel:Ponsel\nEND:VCARD`, 
        sendEphemeral: true 
    }}
});

  return m;
}

module.exports = { MessagesUpsert, Serialize, Solving };

let file = require.resolve(__filename);
fs.watchFile(file, () => {
	fs.unwatchFile(file);
	console.log(`\x1b[41m\x1b[97m ⓘ Reloading ${__filename}! \x1b[0m`);
	delete require.cache[file];
	require(file);
});
