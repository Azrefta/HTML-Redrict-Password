/*

Creator & Dev: Azrefta & Evelyn
Buy? 
 - t.me/Azrefta
 - 6285179993021

*/// Jangan di edit! 

require('../src/settings');
const { registerUser } = require('./AtlasDB');

function handleUserAndGroupRegistration(sender, from) {
    if (!sender.includes('@newsletter')) {
        const userData = {
            owner: false,
            premium: false
        };

        registerUser("settings", {
            autoReadChat: settings.autoReadChat,
            autoReadStatus: settings.autoReadStatus,
            onlyGroupChat: settings.onlyGroupChat,
            ownerModeEnabled: settings.ownerModeEnabled,
            premiumModeEnabled: settings.premiumModeEnabled
        }, "./library/database/bot_db.json");
        
        registerUser("0@s.whatsapp.net", userData);
        registerUser(sender, userData);
    }

    if (from.includes('@g.us')) {
        const groupData = {
            muteGroupChat: false
        };

        registerUser(from, groupData, "./library/database/group_db.json");
    }
}

module.exports = {
    handleUserAndGroupRegistration
};

const fs = require('fs');
let file = require.resolve(__filename);
fs.watchFile(file, () => {
    fs.unwatchFile(file);
    console.log(`\x1b[41m\x1b[97m ⓘ Reloading ${__filename}! \x1b[0m`);
    delete require.cache[file];
    require(file);
});