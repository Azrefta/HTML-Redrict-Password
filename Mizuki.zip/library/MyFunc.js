/*

Creator & Dev: Azrefta & Evelyn
Buy? 
 - t.me/Azrefta
 - 6285179993021

*/// Jangan di edit! 

const {
    proto,
    delay,
    getContentType,
    areJidsSameUser,
    generateWAMessage,
} = require("@whiskeysockets/baileys");
const fs = require("fs");
const axios = require("axios");
const util = require("util");
const Jimp = require("jimp");
const os = require('os');
const path = require("path");

const unixTimestampSeconds = (date = new Date()) =>
    Math.floor(date.getTime() / 1000);

const generateMessageTag = (epoch) => {
    let tag = unixTimestampSeconds().toString();
    if (epoch) tag += ".--" + epoch;
    return tag;
};

const getRandom = (ext) => {
    return `${Math.floor(Math.random() * 10000)}${ext}`;
};

const getBuffer = async (url, options) => {
    try {
        options ? options : {};
        const res = await axios({
            method: "get",
            url,
            headers: {
                DNT: 1,
                "Upgrade-Insecure-Request": 1,
            },
            ...options,
            responseType: "arraybuffer",
        });
        return res.data;
    } catch (err) {
        return err;
    }
};

const fetchJson = async (url, options) => {
    try {
        options ? options : {};
        const res = await axios({
            method: "GET",
            url,
            headers: {
                "User-Agent":
                    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, seperti Gecko) Chrome/95.0.4638.69 Safari/537.36",
            },
            ...options,
        });
        return res.data;
    } catch (err) {
        return err;
    }
};

const runtime = function (seconds) {
    seconds = Number(seconds);
    const d = Math.floor(seconds / (3600 * 24));
    const h = Math.floor((seconds % (3600 * 24)) / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const s = Math.floor(seconds % 60);
    const dDisplay = d > 0 ? d + (d === 1 ? " day, " : " days, ") : "";
    const hDisplay = h > 0 ? h + (h === 1 ? " hour, " : " hours, ") : "";
    const mDisplay = m > 0 ? m + (m === 1 ? " minute, " : " minutes, ") : "";
    const sDisplay = s > 0 ? s + (s === 1 ? " second" : " seconds") : "";
    return dDisplay + hDisplay + mDisplay + sDisplay;
};

const clockString = (ms) => {
    const h = isNaN(ms) ? "--" : Math.floor(ms / 3600000);
    const m = isNaN(ms) ? "--" : Math.floor(ms / 60000) % 60;
    const s = isNaN(ms) ? "--" : Math.floor(ms / 1000) % 60;
    return [h, m, s].map((v) => v.toString().padStart(2, "0")).join(":");
};

const sleep = async (ms) => {
    return new Promise((resolve) => setTimeout(resolve, ms));
};

const isUrl = (url) => {
    return url.match(
        new RegExp(
            /https?:\/\/(www\.)?[-a-zA-Z0-9@:%._+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b([-a-zA-Z0-9()@:%_+.~#?&/=]*)/,
            "gi"
        )
    );
};

function truncateText(input, numberOfViews) {
    if (typeof input !== "string") return "";
    if (
        typeof numberOfViews !== "number" ||
        isNaN(numberOfViews) ||
        numberOfViews < 0
    )
        return input;
    return input.length > numberOfViews
        ? input.substring(0, numberOfViews) + "..."
        : input;
}

const formatDate = (n, locale = "id") => {
    const d = new Date(n);
    return d.toLocaleDateString(locale, {
        weekday: "long",
        day: "numeric",
        month: "long",
        year: "numeric",
        hour: "numeric",
        minute: "numeric",
        second: "numeric",
    });
};

const logic = (check, inp, out) => {
    if (inp.length !== out.length)
        throw new Error("Input and Output must have same length");
    for (let i in inp)
        if (util.isDeepStrictEqual(check, inp[i])) return out[i];
    return null;
};

const generateProfilePicture = async (buffer) => {
    const jimp = await Jimp.read(buffer);
    const min = jimp.getWidth();
    const max = jimp.getHeight();
    const cropped = jimp.crop(0, 0, min, max);
    return {
        img: await cropped.scaleToFit(720, 720).getBufferAsync(Jimp.MIME_JPEG),
        preview: await cropped.scaleToFit(720, 720).getBufferAsync(Jimp.MIME_JPEG),
    };
};

const bytesToSize = (bytes, decimals = 2) => {
    if (bytes === 0) return "0 Bytes";
    const k = 1024;
    const dm = decimals < 0 ? 0 : decimals;
    const sizes = [
        "Bytes",
        "KB",
        "MB",
        "GB",
        "TB",
        "PB",
        "EB",
        "ZB",
        "YB",
    ];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + " " + sizes[i];
};

const getSizeMedia = (pathArg) => {
    return new Promise((resolve, reject) => {
        if (/http/.test(pathArg)) {
            axios
                .get(pathArg)
                .then((res) => {
                    const length = parseInt(res.headers["content-length"]);
                    const size = bytesToSize(length, 3);
                    if (!isNaN(length)) resolve(size);
                })
                .catch(reject);
        } else if (Buffer.isBuffer(pathArg)) {
            const length = Buffer.byteLength(pathArg);
            const size = bytesToSize(length, 3);
            if (!isNaN(length)) resolve(size);
        } else {
            reject("error");
        }
    });
};

const parseMention = (text = "") => {
    return [...text.matchAll(/@([0-9]{5,16}|0)/g)].map(
        (v) => v[1] + "@s.whatsapp.net"
    );
};

const getTimeInfo = () => {
    const options = { timeZone: "Asia/Jakarta", hour12: false };
    const formatter = new Intl.DateTimeFormat("id-ID", {
        weekday: "long",
        day: "2-digit",
        month: "long",
        year: "numeric",
        hour: "2-digit",
        minute: "2-digit",
        second: "2-digit",
        ...options,
    });
    const nowJakarta = new Date().toLocaleString("id-ID", options);
    const nowJayapura = new Date().toLocaleString("id-ID", {
        timeZone: "Asia/Jayapura",
        hour12: false,
    });
    const nowMakassar = new Date().toLocaleString("id-ID", {
        timeZone: "Asia/Makassar",
        hour12: false,
    });
    const [date, time] = formatter.format(new Date()).split(" pukul ");
    const timeJakarta = time.replace(".", ":");
    let greeting = "Selamat Malam 🏙️";
    if (timeJakarta < "19:00:00") greeting = "Selamat Petang 🌆";
    if (timeJakarta < "18:00:00") greeting = "Selamat Sore 🌇";
    if (timeJakarta < "15:00:00") greeting = "Selamat Siang 🌤️";
    if (timeJakarta < "10:00:00") greeting = "Selamat Pagi 🌄";
    if (timeJakarta < "05:00:00") greeting = "Selamat Subuh 🌆";
    if (timeJakarta < "03:00:00") greeting = "Selamat Tengah Malam 🌃";
    const jadwalShalat = {
        shubuh: "04:29",
        terbit: "05:44",
        dhuha: "06:02",
        dzuhur: "12:02",
        ashar: "15:15",
        magrib: "17:52",
        isya: "19:01",
    };
    const now = new Date(
        new Date().toLocaleString("en-US", { timeZone: "Asia/Jakarta" })
    );
    return {
        date,
        timeJakarta,
        nowJakarta,
        nowJayapura,
        nowMakassar,
        greeting,
        jadwalShalat,
        now,
    };
};

const setNet = (input) => {
    if (Array.isArray(input)) {
        return input.map((item) => setNet(item));
    }
    if (typeof input === "number") input = input.toString();
    if (typeof input !== "string") return undefined;
    if (input.endsWith("@g.us") && /^[0-9]+@g\.us$/.test(input)) {
        return input;
    }
    const cleanedNumber = input.replace(/[^0-9]/g, "");
    return cleanedNumber ? `${cleanedNumber}@s.whatsapp.net` : undefined;
};

const extractMentions = (input, version) => {
    if (!input) return [];
    const matches = input.match(/@\S+/g);
    if (!matches) return [];
    return matches.map((mention) => {
        const cleanedMention = mention.replace(/[^0-9]/g, "");
        return version === "@s"
            ? `${cleanedMention}@s.whatsapp.net`
            : cleanedMention;
    });
};

function getInputSender(m, opsi) {
    try {
        if (!m || typeof m !== "object") return false;
        let results = [];
        let mentions = extractMentions(m.budy, "@s");
        if (mentions.length > 0) {
            results = mentions;
        } else {
            const nonMentionNumbers = m.budy
                ? m.budy.match(/\b\d{5,}\b/g)
                : [];
            if (nonMentionNumbers && nonMentionNumbers.length > 0) {
                results = nonMentionNumbers.map(
                    (num) => `${num}@s.whatsapp.net`
                );
            } else if (m.quoted?.sender) {
                results = [
                    `${m.quoted.sender.replace(/[^0-9]/g, "")}@s.whatsapp.net`,
                ];
            }
        }
        return opsi ? results : results.length > 0 ? results[0] : false;
    } catch (error) {
        return false;
    }
}

const totalFitur = (filePath = __filename) => {
    try {
        const absolutePath = path.resolve(filePath);
        const fileContent = fs.readFileSync(absolutePath, "utf-8");
        const caseCount = (fileContent.match(/case/g) || []).length;
        return caseCount.toString();
    } catch (err) {
        console.error(`Gagal membaca file di lokasi: ${filePath}`, err);
        return "0";
    }
};

const toJson = (string) => JSON.stringify(string, null, 2);

const reSize = (buffer, ukur1, ukur2) => {
    return new Promise(async (resolve, reject) => {
        try {
            const baper = await Jimp.read(buffer);
            const ab = await baper.resize(ukur1, ukur2).getBufferAsync(
                Jimp.MIME_JPEG
            );
            resolve(ab);
        } catch (error) {
            reject(error);
        }
    });
};

async function getServerStatus() {
  function formatUptime(seconds) {
    const parts = [];
    const days = Math.floor(seconds / (3600 * 24));
    seconds %= 3600 * 24;
    const hours = Math.floor(seconds / 3600);
    seconds %= 3600;
    const minutes = Math.floor(seconds / 60);
    seconds %= 60;
    if (days > 0) parts.push(`${days}d`);
    if (hours > 0) parts.push(`${hours}h`);
    if (minutes > 0) parts.push(`${minutes}m`);
    if (Math.floor(seconds) > 0 || parts.length === 0) parts.push(`${Math.floor(seconds)}s`);
    return parts.join(' ');
  }

  function formatMemory(bytes) {
    return `${(bytes / (1024 ** 2)).toFixed(2)} MB`;
  }

  const startTime = performance.now();

  await new Promise(resolve => setTimeout(resolve, 100));

  const endTime = performance.now();
  const responseTimeSeconds = (endTime - startTime) / 1000;
  const responseTimeMillis = endTime - startTime;

  const totalMemory = (os.totalmem() / (1024 ** 3)).toFixed(2);
  const usedMemory = ((os.totalmem() - os.freemem()) / (1024 ** 3)).toFixed(2);
  const memoryUsage = process.memoryUsage();
  const cpus = os.cpus();
  const nodeUptime = process.uptime();
  const serverUptime = os.uptime();
  const hostname = os.hostname();
  const serverPort = process.env.PORT || 'N/A';
  const totalServers = process.env.TOTAL_SERVERS || 1;
  const nodeVersion = process.version;
  const serverType = (hostname && hostname.split('-').length - 1 >= 2)
    ? 'Pterodactyl'
    : hostname || 'Unknown';
  const vpsProvider = cpus[0].model.includes('DO') ? 'Digital Ocean' : 'Unknown';

  // Menyusun pesan output
  let message = `🔹 *Response Time*\n` +
                `› ${responseTimeSeconds.toFixed(4)} seconds\n` +
                `› ${responseTimeMillis.toFixed(15)} milliseconds\n\n`;

  message += `💻 *Server Info*\n` +
             `› Hostname : ${serverType}\n` +
             `› Environment : ${process.env.NODE_ENV || 'development'}\n` +
             `› Port : ${serverPort}\n` +
             `› Total Servers : ${totalServers}\n` +
             `› Node.js Uptime : ${formatUptime(nodeUptime)}\n\n`;

  message += `🖥️ *VPS Info*\n` +
             `› VPS Provider : ${vpsProvider}\n` +
             `› CPU Model : ${cpus[0].model}\n` +
             `› Cores : ${cpus.length}\n` +
             `› Uptime : ${formatUptime(serverUptime)}\n\n`;

  message += `📦 *Memory Usage*\n` +
             `› RAM Usage : ${usedMemory} GB / ${totalMemory} GB\n` +
             `› Node Memory :\n` +
             `   › rss : ${formatMemory(memoryUsage.rss)}\n` +
             `   › heapTotal : ${formatMemory(memoryUsage.heapTotal)}\n` +
             `   › heapUsed : ${formatMemory(memoryUsage.heapUsed)}\n` +
             `   › external : ${formatMemory(memoryUsage.external)}\n` +
             `   › arrayBuffers : ${formatMemory(memoryUsage.arrayBuffers)}\n\n`;

  message += `🔧 *CPU Info*\n` +
             `› Model : ${cpus[0].model}\n` +
             `› Per Core Usage :\n`;

  let totalUser = 0, totalSys = 0, totalIdle = 0;
  cpus.forEach((cpu, index) => {
    const total = Object.values(cpu.times).reduce((acc, val) => acc + val, 0);
    const user = ((cpu.times.user / total) * 100).toFixed(2);
    const sys = ((cpu.times.sys / total) * 100).toFixed(2);
    const idle = ((cpu.times.idle / total) * 100).toFixed(2);

    totalUser += parseFloat(user);
    totalSys += parseFloat(sys);
    totalIdle += parseFloat(idle);

    message += `   › Core ${index + 1}:\n` +
               `      - user : ${user}%\n` +
               `      - sys : ${sys}%\n` +
               `      - idle : ${idle}%\n`;
  });

  const coreCount = cpus.length;
  message += `   › Total (Average) :\n` +
             `      - user : ${(totalUser / coreCount).toFixed(2)}%\n` +
             `      - sys : ${(totalSys / coreCount).toFixed(2)}%\n` +
             `      - idle : ${(totalIdle / coreCount).toFixed(2)}%\n`;

  message += `\n⚙️ *Node.js Info*\n` +
             `› Version : ${nodeVersion}\n`;

  return message;
}

module.exports = {
    bytesToSize,
    clockString,
    extractMentions,
    fetchJson,
    formatDate,
    generateMessageTag,
    generateProfilePicture,
    getBuffer,
    getInputSender,
    getRandom,
    getSizeMedia,
    getTimeInfo,
    getServerStatus,
    isUrl,
    logic,
    parseMention,
    reSize,
    runtime,
    setNet,
    sleep,
    toJson,
    totalFitur,
    truncateText,
    unixTimestampSeconds,
};

let file = require.resolve(__filename);
fs.watchFile(file, () => {
    fs.unwatchFile(file);
    console.log(`\x1b[41m\x1b[97m ⓘ Reloading ${__filename}! \x1b[0m`);
    delete require.cache[file];
    require(file);
});