/*

Creator & Dev: Azrefta & Evelyn
Buy? 
 - t.me/Azrefta
 - 6285179993021

*/// Jangan di edit! 

const fs = require("fs")

global.ownerNumber = "+62 851-7999-3021";
global.ownerName = "Azrefta";

// Konfigurasi Bot
global.botName = "YumeMizuki v2.5";
global.footer = `~ ${global.botName}`;
global.botPrefixes = ['.', '!', '?', '/', '$', '%', '^', '&', '*', '#', '@', '+', '~', '|']; //tambahkan jika di perlukan (tidak di sarankan menggunakan emoji)
global.sessionPath = "Connected"; // jangan di ubah

global.settings = {
    antiCallEnabled: true,
    autoReadChat: true,
    autoReadStatus: true,
    onlyGroupChat: true,
    ownerModeEnabled: true,
    premiumModeEnabled: false,
    usePairingCodeEnabled: true,
    markOnlineOnConnect: false
};

//messages
global.mess = {
    done: '✅ Selesai!\n🔥 Proses telah berhasil tanpa hambatan!',  
    ownerOnly: '👑 Fitur ini hanya bisa digunakan oleh Owner.',  
    privateChatOnly: '📩 Fitur ini hanya tersedia dalam obrolan pribadi.',  
    groupOnly: '👥 Fitur ini hanya dapat digunakan dalam grup.',  
    adminOnly: '🔰 Fitur ini hanya dapat digunakan oleh admin grup.',  
    botNotAdmin: '⚠️ Bot harus menjadi admin untuk menggunakan fitur ini.',  
    process: '⏳ Harap bersabar...\n⚡ Proses sedang berlangsung dengan kecepatan maksimal!',  
    premiumOnly: '💎 Fitur ini hanya tersedia untuk pengguna Premium.',
};

global.media = {
    thumb: './src/media/thumb.jpg',
    menu: './src/media/menu.jpg',
    m_other: './src/media/m_other.jpg',
    all_m: './src/media/all_m.jpg'
};

let file = require.resolve(__filename);
fs.watchFile(file, () => {
	fs.unwatchFile(file);
	console.log(`\x1b[41m\x1b[97m ⓘ Reloading ${__filename}! \x1b[0m`);
	delete require.cache[file];
	require(file);
});
