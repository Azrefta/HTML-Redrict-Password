/*

Creator & Dev: Azrefta & Evelyn
Buy? 
 - t.me/Azrefta
 - 6285179993021

*/// Jangan di edit! 

const fs = require('fs');
const path = require('path');

// Konstanta path default untuk database pengguna dan jadwal
const DEFAULT_USER_DB_PATH = path.join(__dirname, './database/user_db.json');
const DEFAULT_SCHEDULE_DB_PATH = path.join(__dirname, './database/schedule_db.json');

// Memuat database pengguna
function loadUserDatabase(customPath) {
    const dbPath = customPath || DEFAULT_USER_DB_PATH;
    if (!fs.existsSync(dbPath)) {
        fs.writeFileSync(dbPath, JSON.stringify({}), 'utf8');
    }
    return JSON.parse(fs.readFileSync(dbPath, 'utf8'));
}

// Menyimpan database pengguna
function saveUserDatabase(database, customPath) {
    const dbPath = customPath || DEFAULT_USER_DB_PATH;
    fs.writeFileSync(dbPath, JSON.stringify(database, null, 4), 'utf8');
}

// Memuat database jadwal (schedule)
function loadSchedule(customPath) {
    const schedulePath = customPath || DEFAULT_SCHEDULE_DB_PATH;
    if (!fs.existsSync(schedulePath)) {
        fs.writeFileSync(schedulePath, JSON.stringify([]), 'utf8');
    }
    return JSON.parse(fs.readFileSync(schedulePath, 'utf8'));
}

// Menyimpan database jadwal (schedule)
function saveSchedule(schedule, customPath) {
    const schedulePath = customPath || DEFAULT_SCHEDULE_DB_PATH;
    fs.writeFileSync(schedulePath, JSON.stringify(schedule, null, 4), 'utf8');
}

// Fungsi utilitas: Mengkonversi nilai ke number.
// Jika nilai berupa string dengan awalan '-', konversi dengan tepat.
function toNumber(val) {
    if (typeof val === 'string' && val.startsWith('-')) {
        return -Number(val.slice(1));
    }
    return Number(val);
}

/* ===== Operasi pada User Database ===== */

/**
 * Mendaftarkan pengguna baru jika belum ada.
 * @param {string} userId 
 * @param {object} data 
 * @param {string} [customPath] 
 */
function registerUser(userId, data, customPath) {
    const db = loadUserDatabase(customPath);
    if (!db[userId]) {
        db[userId] = data;
        saveUserDatabase(db, customPath);
    }
}

/**
 * Mengatur nilai boolean untuk satu pengguna atau semua.
 * @param {string} userId - ID pengguna atau "all"
 * @param {object} updates - Contoh: { premium: true }
 * @param {string} [customPath]
 */
function setBoolean(userId, updates, customPath) {
    const db = loadUserDatabase(customPath);
    if (userId === 'all') {
        for (const uid in db) {
            for (const [key, value] of Object.entries(updates)) {
                if (typeof value !== 'boolean') throw new Error('Error Code 2: Value must be a boolean');
                db[uid][key] = value;
            }
        }
    } else {
        if (!db[userId]) throw new Error('User not found!');
        for (const [key, value] of Object.entries(updates)) {
            if (typeof value !== 'boolean') throw new Error('Error Code 2: Value must be a boolean');
            db[userId][key] = value;
        }
    }
    saveUserDatabase(db, customPath);
}

/**
 * Mengecek apakah pengguna terdaftar di database.
 * @param {string} userId - ID pengguna yang akan dicek.
 * @param {string} [customPath] - Path kustom untuk database pengguna (opsional).
 * @returns {boolean} - Mengembalikan true jika pengguna terdaftar, false jika tidak.
 */
function checkUser(userId, customPath) {
    const db = loadUserDatabase(customPath);
    if (db[userId]) {
        return true;
    } else {
        return false;
    }
}

/**
 * Mengatur data (boolean, number, atau string) untuk pengguna.
 * Mendukung penerapan untuk "all".
 * @param {string} userId 
 * @param {object} updates 
 * @param {string} [customPath]
 */
function setData(userId, updates, customPath) {
    const db = loadUserDatabase(customPath);
    if (userId === 'all') {
        for (const uid in db) {
            for (const [key, value] of Object.entries(updates)) {
                if (typeof value !== 'boolean' && typeof value !== 'number' && typeof value !== 'string') {
                    throw new Error('Error Code 2: Value must be boolean, number, or string');
                }
                db[uid][key] = value;
            }
        }
    } else {
        if (!db[userId]) throw new Error('User not found!');
        for (const [key, value] of Object.entries(updates)) {
            if (typeof value !== 'boolean' && typeof value !== 'number' && typeof value !== 'string') {
                throw new Error('Error Code 2: Value must be boolean, number, or string');
            }
            db[userId][key] = value;
        }
    }
    saveUserDatabase(db, customPath);
}

/**
 * Mengatur nilai array untuk pengguna.
 * Mendukung penerapan untuk "all".
 * @param {string} userId 
 * @param {string} tag 
 * @param {Array} arrayValue 
 * @param {string} [customPath]
 */
function setArray(userId, tag, arrayValue, customPath) {
    if (!Array.isArray(arrayValue)) throw new Error('Error: Value must be an array');
    const db = loadUserDatabase(customPath);
    if (userId === 'all') {
        for (const uid in db) {
            db[uid][tag] = arrayValue;
        }
    } else {
        if (!db[userId]) throw new Error('User not found!');
        db[userId][tag] = arrayValue;
    }
    saveUserDatabase(db, customPath);
}

/**
 * Mengambil nilai sebuah tag untuk pengguna tertentu.
 * @param {string} userId 
 * @param {string} tag 
 * @param {string} [customPath]
 * @returns {any}
 */
function openTag(userId, tag, customPath) {
    const db = loadUserDatabase(customPath);
    if (!db[userId]) throw new Error('User not found! ' + userId);
    return db[userId][tag];
}

/**
 * Mengambil data lengkap pengguna.
 * @param {string} userId 
 * @param {string} [customPath]
 * @returns {object}
 */
function openBase(userId, customPath) {
    const db = loadUserDatabase(customPath);
    if (!db[userId]) throw new Error('User not found! ' + userId);
    return db[userId];
}

/**
 * Mengambil seluruh database pengguna.
 * @param {string} [customPath]
 * @returns {object}
 */
function openDatabase(customPath) {
    return loadUserDatabase(customPath);
}

/**
 * Menghapus data pengguna (atau seluruh pengguna jika "all").
 * @param {string} userId 
 * @param {string} [customPath]
 */
function resetDatabase(userId, customPath) {
    const db = loadUserDatabase(customPath);
    if (userId === 'all') {
        for (const uid in db) {
            delete db[uid];
        }
    } else {
        if (!db[userId]) throw new Error('User not found!');
        delete db[userId];
    }
    saveUserDatabase(db, customPath);
}

/**
 * Mereset sebuah tag untuk pengguna tertentu, dengan opsi pengecualian.
 * @param {string} userId 
 * @param {string} tag 
 * @param {object} [options] - Contoh: { exclude: [{ status: 'premium', Lang: 'id' }] }
 * @param {string} [customPath]
 */
function resetTag(userId, tag, options = {}, customPath) {
    const db = loadUserDatabase(customPath);
    function shouldExclude(userData, excludeArray) {
        for (const filter of excludeArray) {
            let match = true;
            for (const key in filter) {
                if (userData[key] !== filter[key]) {
                    match = false;
                    break;
                }
            }
            if (match) return true;
        }
        return false;
    }
    if (userId === 'all') {
        for (const uid in db) {
            if (options.exclude && Array.isArray(options.exclude)) {
                if (shouldExclude(db[uid], options.exclude)) continue;
            }
            delete db[uid][tag];
        }
    } else {
        if (!db[userId]) throw new Error('User not found!');
        if (options.exclude && Array.isArray(options.exclude)) {
            if (shouldExclude(db[userId], options.exclude)) return;
        }
        delete db[userId][tag];
    }
    saveUserDatabase(db, customPath);
}

/**
 * Melakukan operasi aritmatika pada nilai sebuah tag.
 * Operasi yang didukung: Division, Multiplication, Addition, Substraction.
 * Untuk "Substraction", jika operand berupa string dengan awalan "0", maka pengurangan boleh menghasilkan negatif.
 * @param {string} userId - ID pengguna atau "all"
 * @param {string} tag 
 * @param {object} operation - Contoh: { Addition: 100 }
 * @param {string} [customPath]
 */
function setNumber(userId, tag, operation, customPath) {
    const db = loadUserDatabase(customPath);
    const opTypes = Object.keys(operation);
    if (opTypes.length !== 1) throw new Error('Only one operation allowed at a time');
    const opType = opTypes[0];
    let operand = operation[opType];

    let allowNegative = false;
    if (opType === 'Substraction') {
        if (typeof operand === 'string' && operand.startsWith('0')) {
            allowNegative = true;
            operand = Number(operand);
        } else {
            operand = Number(operand);
        }
    } else {
        operand = Number(operand);
    }

    function updateUser(uid) {
        if (!db[uid]) throw new Error('User not found: ' + uid);
        let currentVal = db[uid][tag] !== undefined ? db[uid][tag] : 0;
        currentVal = toNumber(currentVal);
        let newVal;
        switch (opType) {
            case 'Division':
                if (operand === 0) throw new Error('Division by zero');
                newVal = currentVal / operand;
                if (!Number.isInteger(newVal)) newVal = parseInt(newVal);
                break;
            case 'Multiplication':
                newVal = currentVal * operand;
                break;
            case 'Addition':
                newVal = currentVal + operand;
                break;
            case 'Substraction':
                newVal = currentVal - operand;
                if (!allowNegative && newVal < 0) throw new Error('429');
                break;
            default:
                throw new Error('Invalid operation type');
        }
        db[uid][tag] = newVal < 0 ? '-' + Math.abs(newVal) : newVal;
    }

    if (userId === 'all') {
        for (const uid in db) {
            updateUser(uid);
        }
    } else {
        updateUser(userId);
    }
    saveUserDatabase(db, customPath);
}

/**
 * Fungsi "No Negatif": Jika nilai pada tag negatif, maka direset ke 0.
 * Jika nilai sudah 0 atau positif, maka error.
 * @param {string} userId 
 * @param {string} tag 
 * @param {string} [customPath]
 */
function noNegatif(userId, tag, customPath) {
    const db = loadUserDatabase(customPath);
    function updateUser(uid) {
        if (!db[uid]) throw new Error('User not found: ' + uid);
        let currentVal = toNumber(db[uid][tag]);
        if (currentVal < 0) {
            db[uid][tag] = 0;
        } else {
            throw new Error('Error: Value is not negative');
        }
    }
    if (userId === 'all') {
        for (const uid in db) {
            try {
                updateUser(uid);
            } catch (err) {
                // Lewati jika nilai tidak negatif.
            }
        }
    } else {
        updateUser(userId);
    }
    saveUserDatabase(db, customPath);
}

/**
 * Mencari pengguna berdasarkan properti tertentu.
 * @param {string} sender - ID pengguna yang melakukan pencarian.
 * @param {object} criteria - Contoh: { status: 'premium', vip: true }
 * @param {string} [customPath] - Path custom untuk database (jika ada).
 * @returns {Array} - Array userId yang memenuhi kriteria.
 */
function findUserTag(sender, criteria, customPath) {
    const db = loadUserDatabase(customPath);
    const results = [];

    for (const uid in db) {
        let match = true;

        for (const [key, value] of Object.entries(criteria)) {
            if (db[uid][key] !== value) {
                match = false;
                break;
            }
        }

        if (match) results.push(uid);
    }

    return results;
}

/* ===== Fungsi Penjadwalan (Schedule) ===== */

/**
 * Mengurai string waktu kedaluwarsa menjadi timestamp.
 * Format yang didukung: s, m, h, d, w, mh, yr. Contoh: "1h30m"
 * @param {string} expiredStr 
 * @returns {number|null} - Timestamp masa kedaluwarsa atau null jika format tidak valid.
 */
function parseExpiryTime(expiredStr) {
    const timeMap = { s: 1000, m: 60000, h: 3600000, d: 86400000, w: 604800000, mh: 2592000000, yr: 31536000000 };
    const regex = /(\d+)(s|m|h|d|w|mh|yr)/g;
    let match;
    let totalTime = 0;
    while ((match = regex.exec(expiredStr)) !== null) {
        const value = parseInt(match[1], 10);
        const unit = match[2];
        if (timeMap[unit]) {
            totalTime += value * timeMap[unit];
        }
    }
    return totalTime > 0 ? Date.now() + totalTime : null;
}

/**
 * Mengatur penundaan (delay) pada perubahan sebuah tag.
 * Fungsi ini langsung mengatur nilai dan menjadwalkan perubahan pada tag lain setelah waktu kedaluwarsa.
 * @param {string} userId 
 * @param {object} tagInput - Contoh: { currentTag: newValue }
 * @param {object} delayedInput - Contoh: { delayedTag: delayedValue, Expired: '1h' }
 * @param {string} [customPath]
 */
function setDelay(userId, tagInput, delayedInput, customPath) {
    const db = loadUserDatabase(customPath);
    if (!db[userId]) throw new Error('User not found!');

    const [tagA, valueA] = Object.entries(tagInput)[0];
    const [tagB, valueB] = Object.entries(delayedInput)[0];
    const expiryTime = parseExpiryTime(delayedInput.Expired);
    if (!expiryTime) throw new Error('Invalid Expired format');

    // Atur nilai segera
    db[userId][tagA] = valueA;
    saveUserDatabase(db, customPath);

    // Jadwalkan perubahan tertunda
    const schedule = loadSchedule(customPath);
    schedule.push({ userId, tag: tagB, value: valueB, expiryTime });
    saveSchedule(schedule, customPath);
}

/**
 * Memproses jadwal perubahan yang telah melewati waktu kedaluwarsa.
 * Fungsi ini memeriksa setiap item di schedule dan mengaplikasikan perubahan jika expired.
 * Jika data schedule tidak ada atau kosong, maka fungsi langsung mengembalikan nilai.
 * @param {string} [customPath]
 */
function processExpiredChanges(customPath) {
    const schedule = loadSchedule(customPath);
    
    // Jika tidak ada data di JSON (schedule kosong atau null), maka keluar dari fungsi.
    if (!schedule || schedule.length === 0) {
        return;
    }
    
    const db = loadUserDatabase(customPath);
    const now = Date.now();

    const remainingSchedule = schedule.filter(item => {
        if (now >= item.expiryTime) {
            if (db[item.userId]) {
                db[item.userId][item.tag] = item.value;
            }
            return false; // Hapus item yang sudah expired.
        }
        return true;
    });

    saveSchedule(remainingSchedule, customPath);
    saveUserDatabase(db, customPath);
}

// Proses jadwal perubahan otomatis pada startup dan setiap 1 jam
processExpiredChanges();
setInterval(() => processExpiredChanges(), 3600000);

/* ===== Ekspor Fungsi ===== */
module.exports = {
    registerUser,
    setBoolean,
    setData,
    setArray,
    setNumber,
    openTag,
    openBase,
    openDatabase,
    findUserTag,
    noNegatif,
    resetDatabase,
    resetTag,
    checkUser,
    setDelay,
    processExpiredChanges
};

let file = require.resolve(__filename);
fs.watchFile(file, () => {
	fs.unwatchFile(file);
	console.log(`\x1b[41m\x1b[97m ⓘ Reloading ${__filename}! \x1b[0m`);
	delete require.cache[file];
	require(file);
});