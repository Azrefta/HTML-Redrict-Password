/*

Creator & Dev: Azrefta & Evelyn
Buy? 
 - t.me/Azrefta
 - 6285179993021

*/// Jangan di edit! 

require('./src/settings');
const pino = require('pino');
const fs = require('fs');
const path = require('path');
const readline = require('readline');
const { MessagesUpsert, Solving } = require('./src/message');
const PhoneNumber = require('awesome-phonenumber');
const { Boom } = require('@hapi/boom');
const pkg = require('./package.json');
const baileysPkg = require('@whiskeysockets/baileys/package.json');
const { handleUserAndGroupRegistration } = require('./library/Register');
const { makeWASocket, makeInMemoryStore, useMultiFileAuthState, DisconnectReason, Browsers } =require('@whiskeysockets/baileys');

const BG_HEX = '\x1b[48;5;18m';
const FG_HEX = '\x1b[38;5;18m';
const FG_YELLOW = "\x1b[38;2;255;255;0m";
const FG_WHITE_BRIGHT = "\x1b[97m";
const FG_RED = "\x1b[31m";
const FG_GREEN = "\x1b[32m";
const BG_WHITE = "\x1b[47m";
const RESET = "\x1b[0m";

console.log(
  "\n" + BG_HEX + FG_WHITE_BRIGHT + " 「 YumeMizuki 」 " + RESET +
  FG_WHITE_BRIGHT + "\n • Creator" + FG_HEX +" › " + RESET + "Azrefta (& Evelyn)\n" +
  FG_WHITE_BRIGHT + " • Tanggal Pembuatan" + FG_HEX +" › " + RESET + "2 Maret 2025\n" +
  FG_WHITE_BRIGHT + " • Fitur Utama" + FG_HEX +" › " + RESET + "Bug WhatsApp\n" +
  FG_WHITE_BRIGHT + " • Node.js Module" + FG_HEX +" › " + RESET + "Baileys v" + baileysPkg.version + "\n" +
  FG_WHITE_BRIGHT + " • Versi Script" + FG_HEX +" › " + RESET + "v" + pkg.version + "\n" +
  FG_WHITE_BRIGHT + " • Support Button" + FG_HEX +" › " + RESET + "Yes\n\n"
);

const BOT_CONNECTOR = global.settings?.usePairingCodeEnabled || true;
const BOT_CONNECTEDSTATUS = global.settings?.markOnlineOnConnect || true;
const BOT_SESSIONPATH = global.sessionPath || "azrefta";

const question = (text) => {
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
    return new Promise((resolve) => {
        rl.question(text, (answer) => {
            rl.close();
            resolve(answer);
        });
    });
};

let Eula;

async function runConnection() {
    const store = makeInMemoryStore({ logger: pino().child({ level: 'silent', stream: 'store' }) });
    const version = [2, 3000, 1015901307];
    const { state, saveCreds } = await useMultiFileAuthState(`./${BOT_SESSIONPATH}`);
    const connection = {
        version,
        keepAliveIntervalMs: 30000,
        printQRInTerminal: !BOT_CONNECTOR,
        logger: pino({ level: "silent" }),
        auth: state,
        markOnlineOnConnect: BOT_CONNECTEDSTATUS,
        browser: Browsers.ubuntu('Chrome'),
        getMessage: async (key) => {
            if (store) {
                const msg = await store.loadMessage(key.remoteJid, key.id);
                return msg?.message || undefined;
            }
            return { conversation: 'Eula' };
        }
    };

    Eula = makeWASocket(connection);

    const askPhoneNumber = async () => {
        return new Promise((resolve, reject) => {
            const timer = setTimeout(() => {
                console.error(`${BG_HEX}${FG_WHITE_BRIGHT}  No input for 2 minutes. Script terminated. ${RESET}`);
                process.exit(2);
            }, 120000);

            question(`\n${BG_HEX}${FG_WHITE_BRIGHT} Enter your phone number (starting with 62): ${RESET}\n`)
                .then(answer => {
                    clearTimeout(timer);
                    resolve(answer);
                })
                .catch(err => {
                    clearTimeout(timer);
                    reject(err);
                });
        });
    };

    if (BOT_CONNECTOR && !Eula.authState.creds.registered) {
        fs.readdirSync(BOT_SESSIONPATH).forEach(file => {
            fs.rmSync(path.join(BOT_SESSIONPATH, file), { recursive: true, force: true });
        });
        let phoneNumber = await askPhoneNumber();
        phoneNumber = phoneNumber.replace(/[^0-9]/g, '').trim();
        if (!/^\d+$/.test(phoneNumber)) {
            console.error(`${BG_HEX}${FG_WHITE_BRIGHT}  Only digits are allowed. ${RESET}`);
            return process.exit(2);
        }
        let code = await Eula.requestPairingCode(phoneNumber);
        code = code?.match(/.{1,4}/g)?.join("-") || code;
        console.log(`${BG_HEX}${FG_WHITE_BRIGHT} Pairing Code › ${RESET} ${code}\n`);
    }

    store?.bind(Eula.ev);
    
    Eula.ev.on('call', async (calls) => {
    if (!global.settings.antiCallEnabled) return;

    for (const call of calls) {
        if (call.status === 'offer') {
            await Eula.rejectCall(call.id, call.from);
        }
    }
});

    Eula.ev.on('connection.update', async (update) => {
        const { connection, lastDisconnect, receivedPendingNotifications } = update;
        if (connection === 'close') {
            const reason = new Boom(lastDisconnect?.error)?.output.statusCode;
            const retryConnection = () => {
                console.log(`${BG_HEX}${FG_YELLOW} ⚠ ${BG_HEX}${FG_WHITE_BRIGHT} Reconnecting... ${RESET}`);
                setTimeout(runConnection, 3000);
            };
            const messages = {
                [DisconnectReason.connectionLost]: 'Server Lost. Retrying... ',
                [DisconnectReason.connectionClosed]: 'Connection Closed. Retrying... ',
                [DisconnectReason.restartRequired]: 'Restart Required... ',
                [DisconnectReason.timedOut]: 'Timeout. Retrying... ',
                [DisconnectReason.badSession]: 'Bad Session. Rescan required. ',
                [DisconnectReason.connectionReplaced]: 'Session Replaced. Logout first. ',
                [DisconnectReason.loggedOut]: 'Logged Out. Rescan required. ',
                [DisconnectReason.Multidevicemismatch]: 'Multi-device mismatch. Rescan required. ',
            };
            if (messages[reason]) {
                if (reason === DisconnectReason.connectionLost || reason === DisconnectReason.connectionClosed || reason === DisconnectReason.restartRequired || reason === DisconnectReason.timedOut) {
                    console.log(`${BG_HEX}${FG_YELLOW} ⚠ ${BG_HEX}${FG_WHITE_BRIGHT} ${messages[reason]}${RESET}`);
                } else if (reason === DisconnectReason.badSession || reason === DisconnectReason.connectionReplaced || reason === DisconnectReason.loggedOut || reason === DisconnectReason.Multidevicemismatch) {
                    console.log(`${BG_HEX}${FG_RED} ✘ ${BG_HEX}${FG_WHITE_BRIGHT} ${messages[reason]}${RESET}`);
                }
                if (reason === DisconnectReason.badSession || reason === DisconnectReason.loggedOut || reason === DisconnectReason.Multidevicemismatch) {
                    fs.readdirSync(BOT_SESSIONPATH).forEach(file => {
                        fs.rmSync(path.join(BOT_SESSIONPATH, file), { recursive: true, force: true });
                    });
                    process.exit(reason === DisconnectReason.Multidevicemismatch ? 0 : 1);
                } else if (reason === DisconnectReason.connectionReplaced) {
                    Eula.logout();
                } else {
                    retryConnection();
                }
            } else {
                console.log(`${BG_HEX}${FG_WHITE_BRIGHT}「 ${BG_WHITE}${FG_WHITE_BRIGHT}?${BG_HEX}${FG_WHITE_BRIGHT} 」${BG_HEX}${FG_WHITE_BRIGHT} Unknown Reason: ${reason || 'N/A'} ${RESET}`);
                retryConnection();
            }
        }
        if (connection === 'open') {
            console.log(`${BG_HEX}${FG_GREEN} ✓ ${BG_HEX}${FG_WHITE_BRIGHT} Connected.${RESET}`);
        } else if (receivedPendingNotifications === 'true') {
            console.log(`${BG_HEX}${FG_YELLOW} ⏱ ${BG_HEX}${FG_WHITE_BRIGHT} Processing notifications...${RESET}`);
        }
    });
    
    await Solving(Eula, store);

    Eula.ev.on('creds.update', saveCreds);
    Eula.ev.on('messages.upsert', async (message) => {
        try {
        	const msg = message.messages[0];
        	const fromMe = msg.key.fromMe || false;
        	const from = msg.key.remoteJid || '';
        	const sender = Eula.decodeJid(fromMe ? Eula.user.id : (msg.key.participant || from || '')) || '';
        	await handleUserAndGroupRegistration(sender, from);
            await MessagesUpsert(Eula, message, store);
        } catch (err) {
            console.error(err);
        }
    });
    return Eula;
}

runConnection();

process.on('uncaughtException', (error) => {
    console.error('Caught exception:', error);
});